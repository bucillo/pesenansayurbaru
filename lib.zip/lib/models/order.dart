import 'package:flutter/material.dart';
import 'package:bucil/util/global.dart';

class Order {
  final String id;
  final String date;
  final String total;
  final String description;
  final String statusConfirm;
  final List detail;

  Order.fromJson(Map<String, dynamic> json)
      : id = json["order_id"],
        date = json["date"],
        total = json["total"],
        description = json["description"],
        statusConfirm = json["status_confirm"],
        detail = json["detail"];

  Map<String, dynamic> toJson() => <String, dynamic>{
        'order_id': this.id,
        'date': this.date,
        'total': this.total,
        'description': this.description,
        'status_confirm': this.statusConfirm,
        'detail': this.detail
      };

  static Future<Map> select(
      {@required BuildContext context,
      @required String date,
      String confirm = "%",
      bool showLoading = true}) async {
    Map _parameter = {
      "token": Global.getShared(key: Prefs.PREFS_USER_TOKEN),
      "hash": Global.getShared(key: Prefs.PREFS_USER_HASH),
      "date_start": date,
      "date_end": date,
      "confirm": confirm
    };

    final response = await Global.postTimeout(
        context: context,
        url: "Transaksi_Order/selectData",
        data: _parameter,
        withLoading: showLoading);

    return response;
  }

  static Future<Map> insert(
      {@required BuildContext context,
      @required String date,
      @required String total,
      @required List<OrderDetail> orderDetail,
      bool showLoading = true}) async {
    Map _parameter = {
      "token": Global.getShared(key: Prefs.PREFS_USER_TOKEN),
      "hash": Global.getShared(key: Prefs.PREFS_USER_HASH),
      "store_id": Global.getShared(key: Prefs.PREFS_USER_STORE_ID),
      "date": date,
      "total": total,
      "detail": orderDetail,
    };

    final response = await Global.postTimeout(
        context: context,
        url: "Transaksi_Order/insertData",
        data: _parameter,
        withLoading: showLoading);

    return response;
  }

  static Future<Map> update(
      {@required BuildContext context,
      @required String code,
      @required String date,
      @required String total,
      @required List<OrderDetail> orderDetail,
      bool showLoading = true}) async {
    Map _parameter = {
      "token": Global.getShared(key: Prefs.PREFS_USER_TOKEN),
      "hash": Global.getShared(key: Prefs.PREFS_USER_HASH),
      "code": code,
      "sales_date": date,
      "total": total,
      "detail": orderDetail,
    };

    final response = await Global.postTimeout(
        context: context,
        url: "Transaksi_Order/updateData",
        data: _parameter,
        withLoading: showLoading);

    return response;
  }

  static Future<Map> confirm(
      {@required BuildContext context,
      @required String code,
      bool showLoading = true}) async {
    Map _parameter = {
      "token": Global.getShared(key: Prefs.PREFS_USER_TOKEN),
      "hash": Global.getShared(key: Prefs.PREFS_USER_HASH),
      "code": code
    };

    final response = await Global.postTimeout(
        context: context,
        url: "Transaksi_Order/confirmData",
        data: _parameter,
        withLoading: showLoading);

    return response;
  }

  static Future<Map> delete(
      {@required BuildContext context,
      @required String code,
      bool showLoading = true}) async {
    Map _parameter = {
      "token": Global.getShared(key: Prefs.PREFS_USER_TOKEN),
      "hash": Global.getShared(key: Prefs.PREFS_USER_HASH),
      "code": code
    };

    final response = await Global.postTimeout(
        context: context,
        url: "Transaksi_Order/deleteData",
        data: _parameter,
        withLoading: showLoading);

    return response;
  }
}

class OrderDetail {
  final String productId;
  final String productName;
  final String qty;
  final String price;
  final String unit;
  final String unit1;
  final String unit2;
  final String unit3;
  final String unit4;
  final String unit5;
  final String unitConversion;
  final String unitConversion1;
  final String unitConversion2;
  final String unitConversion3;
  final String unitConversion4;
  final String unitConversion5;
  final String customer;
  final String alamat;
  final String telp;
  final String desc;

  OrderDetail(
      {this.productId,
      this.productName,
      this.qty,
      this.price,
      this.unit,
      this.unit1,
      this.unit2,
      this.unit3,
      this.unit4,
      this.unit5,
      this.unitConversion,
      this.unitConversion1,
      this.unitConversion2,
      this.unitConversion3,
      this.unitConversion4,
      this.unitConversion5,
      this.customer,
      this.alamat,
      this.telp,
      this.desc});

  OrderDetail.fromJson(Map<String, dynamic> json)
      : productId = json["product_id"],
        productName = json["product_name"],
        qty = json["qty"],
        unit = json["unit"],
        unit1 = json["unit1"],
        unit2 = json["unit2"],
        unit3 = json["unit3"],
        unit4 = json["unit4"],
        unit5 = json["unit5"],
        unitConversion = json["unit_conversion"],
        unitConversion1 = json["unit_conversion1"],
        unitConversion2 = json["unit_conversion2"],
        unitConversion3 = json["unit_conversion3"],
        unitConversion4 = json["unit_conversion4"],
        unitConversion5 = json["unit_conversion5"],
        price = json["price"],
        customer = json["customer"],
        alamat = json["alamat"],
        telp = json["telp"],
        desc = json["desc"];

  Map<String, dynamic> toJson() => <String, dynamic>{
        'product_id': this.productId,
        'product_name': this.productName,
        'qty': this.qty,
        'price': this.price,
        'unit': this.unit,
        'unit1': this.unit1,
        'unit2': this.unit2,
        'unit3': this.unit3,
        'unit4': this.unit4,
        'unit5': this.unit5,
        'unit_conversion': this.unitConversion,
        'unit_conversion1': this.unitConversion1,
        'unit_conversion2': this.unitConversion2,
        'unit_conversion3': this.unitConversion3,
        'unit_conversion4': this.unitConversion4,
        'unit_conversion5': this.unitConversion5,
        'customer': this.customer,
        'alamat': this.alamat,
        'telp': this.telp,
        'desc': this.desc,
      };
}
