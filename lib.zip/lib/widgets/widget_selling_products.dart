import 'dart:convert';
import 'package:bucil/screens/content_order_history.dart';
import 'package:bucil/bluetooth_printer.dart';
import 'package:bucil/models/cart.dart';
import 'package:bucil/models/cart_detail.dart';
import 'package:bucil/models/category.dart';
import 'package:bucil/models/product.dart';
import 'package:bucil/printer_settings.dart';
import 'package:bucil/util/const.dart';
import 'package:bucil/util/dialog.dart';
import 'package:bucil/util/global.dart';
import 'package:flutter/material.dart';
import 'package:bucil/screens/content_review.dart';
import 'package:flutter/services.dart';

class ContentProduct extends StatefulWidget {
  final List<Product> product;
  final Category category;
  ContentProduct({this.product, this.category});

  @override
  _ContentProductState createState() => _ContentProductState();
}

class _ContentProductState extends State<ContentProduct> {
  TextEditingController _searchController = new TextEditingController();
  List<Product> productShow = [];
  List<String> currentCartDetail;

  @override
  void initState() {
    super.initState();
    currentCartDetail = [];
    _searchController.addListener(search);
  }

  @override
  void dispose() {
    super.dispose();
    _searchController.dispose();
  }

  void search() {
    productShow = [];
    widget.product.forEach((data) {
      if (widget.category.id == "-1" && data.favourite) {
        if (Global.contains(
            textData: data.name,
            textSearch: _searchController.text)) productShow.add(data);
      } else if (widget.category.id == "0" &&
          Global.contains(
              textData: data.name, textSearch: _searchController.text)) {
        productShow.add(data);
      } else if (data.categoryCode == widget.category.id &&
          Global.contains(
              textData: data.name, textSearch: _searchController.text)) {
        productShow.add(data);
      }
    });

    setState(() {});
  }

  refreshCart() {
    setState(() {
      for (int i = 0; i < widget.product.length; i++) {
        widget.product[i].qty = 0;
        widget.product[i].favourite = false;
      }
      for (int i = 0; i < productShow.length; i++) {
        productShow[i].qty = 0;
        productShow[i].favourite = false;
      }

      currentCartDetail = [];
      currentCartDetail = Global.getSharedList(key: Prefs.PREFS_CART_DETAIL);
      currentCartDetail.forEach((data) {
        CartDetail cartDetail = CartDetail.fromJson(jsonDecode(data));
        for (int i = 0; i < widget.product.length; i++) {
          if (widget.product[i].id == cartDetail.product) {
            widget.product[i].qty += cartDetail.qty;
          }
        }
      });

      List<String> favourite = [];
      favourite = Global.getSharedList(key: Prefs.PREFS_FAVOURITE);
      favourite.forEach((data) {
        for (int i = 0; i < widget.product.length; i++) {
          if (widget.product[i].id == data) {
            widget.product[i].favourite = true;
          }
        }
      });
      search();
    });
  }

  @override
  Widget build(BuildContext context) {
    refreshCart();
    return Container(
      padding: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Container(
            margin:
                EdgeInsets.only(bottom: currentCartDetail.length > 0 ? 55 : 0),
            child: Column(
              children: <Widget>[
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(
                        'assets/image_onboarding.png',
                        width: 355,
                      ),
                      SizedBox(
                        height: 80,
                      ),
                      Text(
                        'Order',
                        style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w500,
                            color: Colors.white),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        'Reseller silakan order ',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w300,
                            color: Colors.white),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(
                        height: 70,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          GestureDetector(
                            onTap: () {
                              Global.materialNavigateReplace(
                                  context, ContentOrderHistory());
                              Global.materialNavigate(
                                  context, ContentOrderHistory());
                            },
                            child: Container(
                              padding: EdgeInsets.symmetric(
                                horizontal: 48,
                                vertical: 14,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.yellow,
                                borderRadius: BorderRadius.horizontal(
                                  left: Radius.circular(20),
                                ),
                              ),
                              child: Text(
                                'Start order >',
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.black),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // Container(
                //   width: MediaQuery.of(context).size.width,
                //   // child: Row(
                //   //   mainAxisSize: MainAxisSize.max,
                //   //   children: <Widget>[
                //   //     Expanded(
                //   //       child: TextFormField(
                //   //         controller: _searchController,
                //   //         decoration: InputDecoration(
                //   //           labelText: "Cari makanan atau minuman",
                //   //           hintText: "Search",
                //   //           prefixIcon: Icon(Icons.search)
                //   //         ),
                //   //       )
                //   //     )
                //   //   ],
                //   // ),
                // ),
                // if (productShow.length > 0) ...[
                //   Flexible(
                //     child: ListView.builder(
                //       padding: EdgeInsets.only(top: 10, left: 10, right: 10),
                //       itemCount: productShow.length,
                //       scrollDirection: Axis.vertical,
                //       shrinkWrap: true,
                //       physics: const AlwaysScrollableScrollPhysics(),
                //       itemBuilder: (BuildContext context, int index) {
                //         if (index > productShow.length - 1) return Container();
                //         Color cardColor = Colors.white;
                //         Color clipColor = Colors.purple;
                //         Color textNameColor = Colors.black87;
                //         Color textPriceColor = Colors.black54;
                //         if (productShow[index].qty > 0) {
                //           cardColor = Colors.orange;
                //           clipColor = Colors.white;
                //           textNameColor = Colors.white;
                //           textPriceColor = Colors.white;
                //         }
                //         String productInitial1 = productShow[index]
                //             .name
                //             .substring(0, 1)
                //             .toUpperCase();
                //         String productInitial2 = productShow[index]
                //             .name
                //             .substring(productShow[index].name.indexOf(" ") + 1,
                //                 productShow[index].name.indexOf(" ") + 2)
                //             .toUpperCase();
                //         return InkWell(
                //           onTap: () {
                //             print(productShow[index].toJson());
                //             Cart.addToCart(
                //                 context: context,
                //                 cartDetail: CartDetail.fromJson({
                //                   "product": productShow[index].id,
                //                   "name": productShow[index].name,
                //                   "has_stock": productShow[index].hasStock,
                //                   "qty_database":
                //                       productShow[index].qtyDatabase,
                //                   "qty": 1.0,
                //                   "price": int.parse(productShow[index].price),
                //                   "product_print":
                //                       productShow[index].productPrints
                //                 }));
                //             refreshCart();
                //           },
                //           child: Card(
                //             elevation: 3,
                //             color: cardColor,
                //             child: Padding(
                //               padding: const EdgeInsets.all(10),
                //               child: Row(
                //                 children: <Widget>[
                //                   SizedBox(
                //                     height: 50,
                //                     width: 50,
                //                     child: ClipRRect(
                //                       borderRadius: BorderRadius.circular(25.0),
                //                       child: Container(
                //                         color: clipColor,
                //                         child: Center(
                //                           child: productShow[index].qty > 0
                //                               ? Text(
                //                                   Global.delimeter(
                //                                       number: productShow[index]
                //                                           .qty
                //                                           .toString()),
                //                                   style: TextStyle(
                //                                     fontSize: 20,
                //                                   ),
                //                                 )
                //                               : Text(
                //                                   "$productInitial1$productInitial2",
                //                                   style: TextStyle(
                //                                       fontSize: 20,
                //                                       color: Colors.white),
                //                                 ),
                //                         ),
                //                       ),
                //                     ),
                //                   ),
                //                   SizedBox(
                //                     width: 10,
                //                   ),
                //                   Expanded(
                //                     flex: 5,
                //                     child: Column(
                //                       crossAxisAlignment:
                //                           CrossAxisAlignment.start,
                //                       children: <Widget>[
                //                         Text(productShow[index].name,
                //                             style: TextStyle(
                //                                 fontSize: 14,
                //                                 color: textNameColor,
                //                                 fontWeight: FontWeight.w500)),
                //                         Text(
                //                             "Harga: Rp. " +
                //                                 Global.delimeter(
                //                                     number: productShow[index]
                //                                         .price),
                //                             style: TextStyle(
                //                                 fontSize: 12,
                //                                 fontStyle: FontStyle.italic,
                //                                 color: textPriceColor))
                //                       ],
                //                     ),
                //                   ),
                //                   if (productShow[index].qty >= 1.0) ...[
                //                     Expanded(
                //                       flex: 1,
                //                       child: InkWell(
                //                         onTap: () {
                //                           Cart.addToCart(
                //                               context: context,
                //                               cartDetail: CartDetail.fromJson({
                //                                 "product":
                //                                     productShow[index].id,
                //                                 "name": productShow[index].name,
                //                                 "has_stock":
                //                                     productShow[index].hasStock,
                //                                 "qty_database":
                //                                     productShow[index]
                //                                         .qtyDatabase,
                //                                 "qty": -1.0,
                //                                 "product_print":
                //                                     productShow[index]
                //                                         .productPrints,
                //                                 "price": int.parse(
                //                                     productShow[index].price),
                //                               }));
                //                           refreshCart();
                //                         },
                //                         child: SizedBox(
                //                           height: 50,
                //                           width: 50,
                //                           child: ClipRRect(
                //                             borderRadius:
                //                                 BorderRadius.circular(25),
                //                             child: Container(
                //                               color: Colors.white,
                //                               child: Center(
                //                                 child: Icon(
                //                                   Icons.remove,
                //                                   size: 30,
                //                                   color: Colors.blue,
                //                                 ),
                //                               ),
                //                             ),
                //                           ),
                //                         ),
                //                       ),
                //                     )
                //                   ] else ...[
                //                     Expanded(
                //                       flex: 1,
                //                       child: InkWell(
                //                         onTap: () {
                //                           List<String> favourite = [];
                //                           favourite = Global.getSharedList(
                //                               key: Prefs.PREFS_FAVOURITE);
                //                           if (productShow[index].favourite) {
                //                             for (int i = 0;
                //                                 i < favourite.length;
                //                                 i++) {
                //                               if (favourite[i] ==
                //                                   productShow[index].id)
                //                                 favourite.removeAt(i);
                //                             }
                //                           } else
                //                             favourite
                //                                 .add(productShow[index].id);

                //                           Global.setSharedList(
                //                               key: Prefs.PREFS_FAVOURITE,
                //                               value: favourite);
                //                           refreshCart();
                //                         },
                //                         child: SizedBox(
                //                           height: 50,
                //                           width: 50,
                //                           child: ClipRRect(
                //                             borderRadius:
                //                                 BorderRadius.circular(25),
                //                             child: Container(
                //                               child: Center(
                //                                 child: Icon(
                //                                   Icons.star,
                //                                   size: 30,
                //                                   color: (productShow[index]
                //                                           .favourite)
                //                                       ? Colors.yellow
                //                                       : Colors.grey,
                //                                 ),
                //                               ),
                //                             ),
                //                           ),
                //                         ),
                //                       ),
                //                     )
                //                   ]
                //                 ],
                //               ),
                //             ),
                //           ),
                //         );
                //       },
                //     ),
                //   )
                // ]
              ],
            ),
          ),
          if (currentCartDetail.length > 0) ...[
            Align(
              alignment: Alignment.bottomCenter,
              child: InkWell(
                onTap: () async {
                  FocusScope.of(context).requestFocus(new FocusNode());
                  String shift = Global.getShared(
                      key: Prefs.PREFS_USER_SHIFT, defaults: "0");
                  if (shift == "1") {
                    bool isBTOn = false;
                    isBTOn = await _isBTEnabled();
                    if (!isBTOn) {
                      Dialogs.showYesNo(
                          context: context,
                          text:
                              'Bluetooth belum dinyalakan. Jika bluetooth dalam kondisi mati, invoice tidak akan dicetak. \nLanjutkan?',
                          action: (choiceYes) {
                            if (choiceYes) {
                              // checkPrinterSettings();
                              Global.materialNavigate(context, ContentReview());
                            }
                          });
                    }
                    // else checkPrinterSettings();
                    else
                      Global.materialNavigate(context, ContentReview());
                  } else if (shift == "0") {
                    Dialogs.showSimpleText(
                        context: context,
                        text: "Lakukan buka shift terlebih dahulu");
                  }
                },
                child: Container(
                  width: double.infinity,
                  height: 50,
                  color: Constants.lightAccent,
                  child: Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Lihat Pesanan",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w500),
                    ),
                  ),
                ),
              ),
            )
          ]
        ],
      ),
    );
  }

  void checkPrinterSettings() {
    //? check printer setting, jika belum disetting muncul dialog untuk mengarahkan ke settings
    if (Printing().isPrinterInvAvailable()) {
      Global.materialNavigate(context, ContentReview());
      //? dialogs printer dapur tidak diperlukan
      // if (Printing().isPrinterKitchenAvailable()) {
      //   Global.materialNavigate(context, ContentReview());
      // } else {
      //   Dialogs.showYesNo(
      //       context: context,
      //       text: 'Printer dapur belum dipilih. Pilih sekarang?',
      //       action: (choiceYes) {
      //         if (choiceYes) {
      //           Global.materialNavigate(context, PrinterSettings());
      //         } else {
      //           Global.materialNavigate(context, ContentReview());
      //         }
      //       });
      // }
    } else {
      Dialogs.showYesNo(
          context: context,
          text: 'Printer invoice belum dipilih. Pilih sekarang?',
          action: (choiceYes) {
            if (choiceYes)
              Global.materialNavigate(context, PrinterSettings());
            else
              Global.materialNavigate(context, ContentReview());
          });
    }
  }

  bool _isDisposed = false;
  static const platform = const MethodChannel("printer");

  Future<bool> _isBTEnabled() async {
    bool _isBluetoothEnabled = false;
    if (_isDisposed) return _isBluetoothEnabled;
    try {
      bool tempBool = await platform.invokeMethod('isBluetoothEnabled');
      setState(() {
        _isBluetoothEnabled = tempBool;
        // _isLoading = false;
      });
      print('_isBluetoothEnabled : $_isBluetoothEnabled');
    } catch (e) {
      setState(() {
        _isBluetoothEnabled = false;
      });
    }
    return _isBluetoothEnabled;
  }
}
