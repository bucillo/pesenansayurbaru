import 'dart:convert';

import 'package:bucil/models/product_print.dart';
import 'package:bucil/printer_list.dart';
import 'package:bucil/util/const.dart';
import 'package:flutter/material.dart';

import 'bluetooth_printer.dart';
import 'models/invoice.dart';
import 'models/printer.dart';
import 'util/global.dart';

class PrinterSettings extends StatefulWidget {
  @override
  _PrinterSettingsState createState() => _PrinterSettingsState();
}

class _PrinterSettingsState extends State<PrinterSettings> {
  List<Printer> printerInvoice = [];
  List<Printer> printerKitchen = [];
  List<Printer> printerFood = [];
  List<Printer> printerDrink = [];

  @override
  void initState() {
    super.initState();
    loadPrinterList();
  }

  void loadPrinterList() {
    if (Global.getShared(key: Prefs.PREFS_BLUETOOTH_PRINTER_INVOICE).toString().isNotEmpty) {
      ArrayOfPrinter arrayOfPrinter = ArrayOfPrinter.fromJson(jsonDecode(Global.getShared(key: Prefs.PREFS_BLUETOOTH_PRINTER_INVOICE)));
      printerInvoice = arrayOfPrinter.printers;
    }
    if (Global.getShared(key: Prefs.PREFS_BLUETOOTH_PRINTER_KITCHEN).toString().isNotEmpty) {
      ArrayOfPrinter arrayOfPrinter = ArrayOfPrinter.fromJson(jsonDecode(Global.getShared(key: Prefs.PREFS_BLUETOOTH_PRINTER_KITCHEN)));
      printerKitchen = arrayOfPrinter.printers;
    }
    if (Global.getShared(key: Prefs.PREFS_BLUETOOTH_PRINTER_FOOD).toString().isNotEmpty) {
      ArrayOfPrinter arrayOfPrinter = ArrayOfPrinter.fromJson(jsonDecode(Global.getShared(key: Prefs.PREFS_BLUETOOTH_PRINTER_FOOD)));
      printerFood = arrayOfPrinter.printers;
    }
    if (Global.getShared(key: Prefs.PREFS_BLUETOOTH_PRINTER_DRINK).toString().isNotEmpty) {
      ArrayOfPrinter arrayOfPrinter = ArrayOfPrinter.fromJson(jsonDecode(Global.getShared(key: Prefs.PREFS_BLUETOOTH_PRINTER_DRINK)));
      printerDrink = arrayOfPrinter.printers;
    }

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Printer Settings',
          style: TextStyle(color: Colors.white),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Container(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: ListView(
            children: getPrinterList(),
          ),
        ),
      ),
      bottomNavigationBar: Container(
        width: double.infinity,
        color: Constants.lightAccent,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                TextButton(
                  child: Text(
                    'Test Print Invoice',
                    style:
                        TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
                  ),
                  onPressed: () async {
                    List<InvoiceDetail> invoiceDetails = [];
                    List<dynamic> productPrint = [];
                    productPrint.add(jsonEncode(new ProductPrint("makanan", "1")));
                    productPrint.add(jsonEncode(new ProductPrint("minuman", "2")));
                    InvoiceDetail invoiceDetail = InvoiceDetail(
                      itemName: 'test',
                      price: '1000',
                      qty: '1',
                      detailSubtotal: '1000',
                      productPrints: productPrint,
                    );
                    invoiceDetails.add(invoiceDetail);
                    InvoiceHeader invoiceHeader = InvoiceHeader(
                      customerName: 'test',
                      headerDiscPercent: '0',
                      headerDiscValue: '0',
                      headerSubtotal: '0',
                      headerTotal: '0',
                      payAmount: '0',
                    );
                    Invoice invoice = Invoice(
                        code: 'Invoice test',
                        invoiceHeader: invoiceHeader,
                        invoiceDetail: invoiceDetails,
                        footer: 'Terima kasih');
                    // bool print = false;
                    Printing().printMultiple(context, invoice, PrinterType.PRINTER_INVOICE);
                  },
                ),
                TextButton(
                  child: Text(
                    'Test Print Dapur',
                    style:
                        TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
                  ),
                  onPressed: () async {
                    List<InvoiceDetail> invoiceDetails = [];
                    List<dynamic> productPrint = [];
                    productPrint.add(jsonEncode(new ProductPrint("makanan", "1")));
                    productPrint.add(jsonEncode(new ProductPrint("minuman", "2")));
                    InvoiceDetail invoiceDetail = InvoiceDetail(
                      itemName: 'test',
                      price: '1000',
                      qty: '1',
                      detailSubtotal: '1000',
                      productPrints: productPrint
                    );
                    invoiceDetails.add(invoiceDetail);
                    InvoiceHeader invoiceHeader = InvoiceHeader(
                      customerName: 'test',
                      headerDiscPercent: '0',
                      headerDiscValue: '0',
                      headerSubtotal: '0',
                      headerTotal: '0',
                      payAmount: '0',
                    );
                    Invoice invoice = Invoice(
                        code: 'Invoice test',
                        invoiceHeader: invoiceHeader,
                        invoiceDetail: invoiceDetails,
                        footer: 'Terima kasih');
                    // bool print = false;
                    Printing().printMultiple(
                        context, invoice, PrinterType.PRINTER_KITCHEN);
                  },
                ),
              ],
            ),


            Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                TextButton(
                  child: Text(
                    'Test Print Makanan',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
                  ),
                  onPressed: () async {
                    List<InvoiceDetail> invoiceDetails = [];
                    List<dynamic> productPrint = [];
                    productPrint.add(jsonDecode(jsonEncode(new ProductPrint("makanan", "1"))));
                    productPrint.add(jsonDecode(jsonEncode(new ProductPrint("minuman", "2"))));
                    InvoiceDetail invoiceDetail = InvoiceDetail(
                      itemName: 'test',
                      price: '1000',
                      qty: '1',
                      detailSubtotal: '1000',
                      productPrints: productPrint
                    );
                    invoiceDetails.add(invoiceDetail);
                    InvoiceHeader invoiceHeader = InvoiceHeader(
                      customerName: 'test',
                      headerDiscPercent: '0',
                      headerDiscValue: '0',
                      headerSubtotal: '0',
                      headerTotal: '0',
                      payAmount: '0',
                    );
                    Invoice invoice = Invoice(
                        code: 'Invoice test',
                        invoiceHeader: invoiceHeader,
                        invoiceDetail: invoiceDetails,
                        footer: 'Terima kasih');
                    // bool print = false;
                    Printing().printMultiple(context, invoice, PrinterType.PRINTER_FOOD, showLoading: false);
                  },
                ),
                TextButton(
                  child: Text(
                    'Test Print Minuman',
                    style:TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
                  ),
                  onPressed: () async {
                    List<InvoiceDetail> invoiceDetails = [];
                    List<dynamic> productPrint = [];
                    productPrint.add(jsonDecode(jsonEncode(new ProductPrint("makanan", "1"))));
                    productPrint.add(jsonDecode(jsonEncode(new ProductPrint("minuman", "2"))));
                    InvoiceDetail invoiceDetail = InvoiceDetail(
                      itemName: 'test',
                      price: '1000',
                      qty: '1',
                      detailSubtotal: '1000',
                      productPrints: productPrint
                    );
                    invoiceDetails.add(invoiceDetail);
                    InvoiceHeader invoiceHeader = InvoiceHeader(
                      customerName: 'test',
                      headerDiscPercent: '0',
                      headerDiscValue: '0',
                      headerSubtotal: '0',
                      headerTotal: '0',
                      payAmount: '0',
                    );
                    Invoice invoice = Invoice(
                        code: 'Invoice test',
                        invoiceHeader: invoiceHeader,
                        invoiceDetail: invoiceDetails,
                        footer: 'Terima kasih');
                    // bool print = false;
                    Printing().printMultiple(context, invoice, PrinterType.PRINTER_DRINK, showLoading: false);
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> getPrinterList() {
    Widget printerInvoiceHeader = Container(
        color: Colors.grey,
        padding: EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Text(
              'Printer Invoice',
              style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
            ),
            IconButton(
              icon: Icon(Icons.list, color: Colors.white,),
              onPressed: () async {
                await Global.materialNavigate(
                    context,
                    PrinterList(
                      type: PrinterType.PRINTER_INVOICE,
                    )).then((_) {
                  loadPrinterList();
                });
              },
            ),
          ],
        ));

    Widget listPrinterInvoice = ListView.builder(
      shrinkWrap: true,
      itemCount: printerInvoice != null ? printerInvoice.length : 0,
      itemBuilder: (context, index) {
        return Container(
          margin: EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                  '${printerInvoice[index].printerName} (${printerInvoice[index].printerId})'),
              Divider(),
            ],
          ),
        );
      },
    );

    Widget printerKitchenHeader = Container(
        color: Colors.grey,
        padding: EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Text(
              'Printer Dapur',
              style:TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
            ),
            IconButton(
              icon: Icon(
                Icons.list,
                color: Colors.white,
              ),
              onPressed: () async {
                await Global.materialNavigate(
                  context,
                  PrinterList(type: PrinterType.PRINTER_KITCHEN)
                ).then((_) {loadPrinterList(); });
              },
            ),
          ],
        ));

    Widget listPrinterKitchen = ListView.builder(
      shrinkWrap: true,
      itemCount: printerKitchen != null ? printerKitchen.length : 0,
      itemBuilder: (context, index) {
        return Container(
          margin: EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Text(
                  '${printerKitchen[index].printerName} (${printerKitchen[index].printerId})'),
              Divider(),
            ],
          ),
        );
      },
    );

    Widget printerFoodHeader = Container(
        color: Colors.grey,
        padding: EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Text(
              'Printer Makanan',
              style:TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
            ),
            IconButton(
              icon: Icon(
                Icons.list,
                color: Colors.white,
              ),
              onPressed: () async {
                await Global.materialNavigate(
                  context,
                  PrinterList(type: PrinterType.PRINTER_FOOD)
                ).then((_) {loadPrinterList(); });
              },
            ),
          ],
        ));

    Widget listPrinterFood = ListView.builder(
      shrinkWrap: true,
      itemCount: printerFood != null ? printerFood.length : 0,
      itemBuilder: (context, index) {
        return Container(
          margin: EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Text(
                  '${printerFood[index].printerName} (${printerFood[index].printerId})'),
              Divider(),
            ],
          ),
        );
      },
    );


    Widget printerDrinkHeader = Container(
        color: Colors.grey,
        padding: EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Text(
              'Printer Minuman',
              style:TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
            ),
            IconButton(
              icon: Icon(
                Icons.list,
                color: Colors.white,
              ),
              onPressed: () async {
                await Global.materialNavigate(
                  context,
                  PrinterList(type: PrinterType.PRINTER_DRINK)
                ).then((_) {loadPrinterList(); });
              },
            ),
          ],
        ));

    Widget listPrinterDrink = ListView.builder(
      shrinkWrap: true,
      itemCount: printerDrink != null ? printerDrink.length : 0,
      itemBuilder: (context, index) {
        return Container(
          margin: EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Text(
                  '${printerDrink[index].printerName} (${printerDrink[index].printerId})'),
              Divider(),
            ],
          ),
        );
      },
    );
    return <Widget>[
      printerInvoiceHeader,
      Divider(),
      listPrinterInvoice,
      printerKitchenHeader,
      Divider(),
      listPrinterKitchen,
      printerFoodHeader,
      Divider(),
      listPrinterFood,
      printerDrinkHeader,
      Divider(),
      listPrinterDrink,
    ];
  }
}
