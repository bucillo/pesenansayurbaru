import 'package:bucil/models/shift.dart';
import 'package:bucil/util/const.dart';
import 'package:bucil/util/dialog.dart';
import 'package:bucil/util/global.dart';
import 'package:flutter/material.dart';
import '../bluetooth_printer.dart';

//PAGE REVIEW RECAP
class ContentRecapReview extends StatefulWidget {
  final data;
  final cashier;
  const ContentRecapReview({Key key, this.data, this.cashier = ""})
      : super(key: key);

  @override
  _ContentRecapReviewState createState() => _ContentRecapReviewState();
}

class _ContentRecapReviewState extends State<ContentRecapReview> {
  List<ShiftDetail> _shiftDetail = [];
  String cashier = Global.getShared(key: Prefs.PREFS_USER_NAME);

  @override
  void initState() {
    super.initState();
    if (widget.cashier != "") cashier = widget.cashier;
    widget.data.forEach((data) {
      print("REKAP :: " + data.toString());
      _shiftDetail.add(ShiftDetail.fromJson(data));
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: SafeArea(
        child: Scaffold(
            appBar: AppBar(
                leading: Container(),
                actions: <Widget>[
                  IconButton(
                    icon: Icon(Icons.sync, color: Constants.lightNavbarBG),
                    onPressed: null,
                  ),
                ],
                backgroundColor: Constants.lightAccent,
                title: Center(
                    child: Text(
                  "Rekapan",
                  style: TextStyle(color: Constants.lightNavbarBG),
                ))),
            body: _content()),
      ),
    );
  }

  Widget _content() {
    return Column(
      children: <Widget>[
        Expanded(
            child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: <Widget>[list(), submit()],
            ),
          ),
        ))
      ],
    );
  }

  Widget list() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          "Kasir: " + cashier,
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        if (_shiftDetail.length > 0) ...[
          Text(
              "Jam buka: " +
                  Global.formatDate(
                      date: _shiftDetail[0].shiftOpen,
                      inputPattern: Global.DATETIME_DATABASE,
                      outputPattern: Global.DATETIME_SHOW_DETAIL),
              style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic)),
        ],
        if (_shiftDetail.length > 0) ...[
          Text(
              "Jam tutup: " +
                  Global.formatDate(
                      date: _shiftDetail[0].shiftClose,
                      inputPattern: Global.DATETIME_DATABASE,
                      outputPattern: Global.DATETIME_SHOW_DETAIL),
              style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic)),
        ],
        SizedBox(height: 30),
        Text(
          "Rekap Menu Terjual",
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        Divider(height: 10, thickness: 2),
        ListView.builder(
            padding: EdgeInsets.only(right: 5),
            itemCount: _shiftDetail[0].detailItem.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (BuildContext context, int index) {
              return Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Expanded(
                          flex: 3,
                          child: Text(Global.delimeter(
                                  number: _shiftDetail[0]
                                      .detailItem[index]
                                      .productQty) +
                              "x " +
                              _shiftDetail[0].detailItem[index].productName),
                        ),
                        Expanded(
                          flex: 1,
                          child: Text(
                            "Rp. " +
                                Global.delimeter(
                                    number: (double.parse(_shiftDetail[0]
                                                .detailItem[index]
                                                .productQty) *
                                            double.parse(_shiftDetail[0]
                                                .detailItem[index]
                                                .productPrice))
                                        .toString()),
                            textAlign: TextAlign.end,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 5)
                  ],
                ),
              );
            }),
        SizedBox(height: 30),
        Text(
          "Rekap Metode Pembayaran",
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        Divider(height: 10, thickness: 2),
        ListView.builder(
            padding: EdgeInsets.only(top: 10, left: 10, right: 10),
            itemCount: _shiftDetail.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (BuildContext context, int index) {
              String symbol = "=";
              int different = 0;
              if (_shiftDetail[index].shiftTotalSales !=
                  _shiftDetail[index].shiftTotalUsers) {
                if (int.parse(_shiftDetail[index].shiftTotalSales) <
                    int.parse(_shiftDetail[index].shiftTotalUsers)) {
                  symbol = "+";
                  different = int.parse(_shiftDetail[index].shiftTotalUsers) -
                      int.parse(_shiftDetail[index].shiftTotalSales);
                } else {
                  symbol = "-";
                  different = int.parse(_shiftDetail[index].shiftTotalSales) -
                      int.parse(_shiftDetail[index].shiftTotalUsers);
                }
              }

              return Column(
                children: <Widget>[
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(_shiftDetail[index].paymentmethodName),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: <Widget>[
                          Text(
                            "Rp. " +
                                Global.delimeter(
                                    number:
                                        _shiftDetail[index].shiftTotalSales),
                            style: TextStyle(
                                color: (_shiftDetail[index].shiftTotalSales ==
                                        _shiftDetail[index].shiftTotalUsers)
                                    ? Colors.black
                                    : (int.parse(_shiftDetail[index]
                                                .shiftTotalSales) <
                                            int.parse(_shiftDetail[index]
                                                .shiftTotalUsers))
                                        ? Colors.green
                                        : Colors.red,
                                fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: 10),
                          Text(
                            "Rp. " +
                                Global.delimeter(
                                    number:
                                        _shiftDetail[index].shiftTotalUsers),
                            style: TextStyle(
                                color: (_shiftDetail[index].shiftTotalSales ==
                                        _shiftDetail[index].shiftTotalUsers)
                                    ? Colors.black
                                    : (int.parse(_shiftDetail[index]
                                                .shiftTotalSales) <
                                            int.parse(_shiftDetail[index]
                                                .shiftTotalUsers))
                                        ? Colors.green
                                        : Colors.red,
                                fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: 10),
                          Text(
                            "(" +
                                symbol +
                                ") Rp. " +
                                Global.delimeter(number: different.toString()),
                            style: TextStyle(
                                color: (_shiftDetail[index].shiftTotalSales ==
                                        _shiftDetail[index].shiftTotalUsers)
                                    ? Colors.black
                                    : (int.parse(_shiftDetail[index]
                                                .shiftTotalSales) <
                                            int.parse(_shiftDetail[index]
                                                .shiftTotalUsers))
                                        ? Colors.green
                                        : Colors.red,
                                fontWeight: FontWeight.bold),
                          )
                        ],
                      )
                    ],
                  ),
                  Divider(),
                  SizedBox(height: 20)
                ],
              );
            }),
        SizedBox(height: 20),
      ],
    );
  }

  Widget submit() {
    return Column(
      children: <Widget>[
        InkWell(
          child: Container(
              width: double.infinity,
              height: 50,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Constants.darkAccent),
                  color: Constants.darkAccent),
              child: Center(
                  child: Text(
                "Selesai",
                style: TextStyle(color: Colors.white),
              ))),
          onTap: () async {
            // bool isBtEnabled = await Printing().isBTEnabled();
            // if (isBtEnabled) {
            //   if (Printing().isPrinterInvAvailable()) {
            //     bool isPrintSuccess =
            //         await Printing().printRecap(context, cashier, _shiftDetail);
            //     Navigator.pop(context);

            //     //! TIDAK PERLU DIALOG PRINT ULANG KALAU GAGAL PRINT
            //     // if (isPrintSuccess)
            //     //   Navigator.pop(context);
            //     // else {
            //     //   tryReprintRecap(context, _shiftDetail);
            //     // }
            //   } else {
            //     //! KALAU GAGAL TIDAK ADA PRINTER, SKIP
            //     Navigator.pop(context);
            //     Dialogs.showSimpleText(
            //         context: context,
            //         text: 'Cetak gagal. Printer untuk rekap belum disetting');
            //   }
            // } else {
            //   //! KALAU GAGAL BT TIDAK NYALA, SKIP
            //   Navigator.pop(context);
            //   Dialogs.showSimpleText(
            //       context: context,
            //       text: 'Cetak gagal. Cek koneksi bluetooth dan coba lagi.');
            // }
            Dialogs.showYesNo(
                context: context,
                text: 'Cetak rekapan shift?',
                action: (yes) async {
                  if (yes) {
                    bool isBtEnabled = await Printing().isBTEnabled();
                    if (isBtEnabled) {
                      if (Printing().isPrinterInvAvailable()) {
                        bool isPrintSuccess = await Printing()
                            .printRecap(context, cashier, _shiftDetail);
                        if (isPrintSuccess)
                          Navigator.pop(context);
                        else {
                          tryReprintRecap(context, _shiftDetail);
                        }
                      } else {
                        //! KALAU GAGAL TIDAK ADA PRINTER
                        Dialogs.showSimpleText(
                            context: context,
                            text:
                                'Cetak gagal. Printer untuk rekap belum disetting');
                      }
                    } else {
                      //! KALAU GAGAL BT TIDAK NYALA
                      Dialogs.showSimpleText(
                          context: context,
                          text:
                              'Cetak gagal. Cek koneksi bluetooth dan coba lagi.');
                    }
                  }
                });
          },
        ),
      ],
    );
  }

  void tryReprintRecap(BuildContext context, List<ShiftDetail> shiftDetail) {
    Dialogs.showReprintRecap(
        title: 'Cetak rekap shift gagal',
        context: context,
        action: (type) async {
          Navigator.pop(context);
          if (type == 0) {
            print('Print ulang rekap');
            if (!Printing().isPrinterInvAvailable()) {
              Dialogs.showSimpleText(
                  context: context,
                  text: 'Cetak nota gagal. Printer invoice belum disetting.');
              return;
            }
            Printing().printRecap(context, cashier, _shiftDetail,
                failedAction: () {
              tryReprintRecap(context, shiftDetail);
            }, successAction: () {
              Navigator.pop(context);
            });
          } else if (type == 1) {
            //? back to home
            Navigator.pop(context);
          }
        },
        skipButton: true);
  }
}
