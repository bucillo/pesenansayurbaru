import 'package:bucil/models/api.dart';
import 'package:bucil/models/order.dart';
import 'package:bucil/screens/content_order.dart';
import 'package:bucil/util/dialog.dart';
import 'package:bucil/util/global.dart';
import 'package:flutter/material.dart';
import 'package:bucil/util/const.dart';
import 'package:bucil/models/auth.dart';
import 'package:bucil/models/product.dart';

import 'package:bucil/models/customer.dart';
import 'package:bucil/screens/content_absence_start.dart';
import 'package:bucil/screens/content_order_start.dart';
import 'package:package_info/package_info.dart';

import 'package:bucil/models/cart.dart';
import 'package:bucil/models/category.dart';
import 'package:bucil/models/paymentmethod.dart';

import 'package:bucil/models/salestype.dart';
import 'package:bucil/models/shift.dart';
import 'package:bucil/models/syncronize.dart';
import 'package:bucil/screens/content_history.dart';
import 'package:bucil/screens/content_history_recap.dart';
import 'package:bucil/screens/content_recap.dart';

import 'package:bucil/widgets/widget_selling_products.dart';

class ContentOrderHistory extends StatefulWidget {
  final DateTime dateTime;

  const ContentOrderHistory({Key key, this.dateTime}) : super(key: key);

  @override
  _ContentOrderHistoryState createState() => _ContentOrderHistoryState();
}

class _ContentOrderHistoryState extends State<ContentOrderHistory> {
  int total = 0;
  int totalTransaction = 0;
  List<Order> _order = [];
  List<Product> product;
  DateTime date = DateTime.now();

  @override
  void initState() {
    super.initState();
    if (widget.dateTime != null) date = widget.dateTime;
    date = new DateTime(date.year, date.month, date.day);
    Future.delayed(Duration.zero, () async {
      select();
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Constants.lightNavbarBG,
        // title: Text(
        //   "Order List",
        //   style: TextStyle(color: Constants.lightAccent),
        // ),
        title: Text("Order List"),
        actions: <Widget>[
          Stack(
            children: <Widget>[
              IconButton(
                icon: Icon(Icons.lock),
                onPressed: () {
                  Dialogs.showYesNo(
                      context: context,
                      text: "Apakah anda yakin untuk keluar?",
                      action: (result) {
                        if (result) {
                          Auth.logout(context);
                        }
                      });
                },
              ),
            ],
          ),
        ],
      ),
      body: SafeArea(
          child: Container(
              child: SingleChildScrollView(
        physics: ScrollPhysics(),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      Global.selectDate(context, initialDate: date)
                          .then((dateNew) {
                        if (dateNew != null) {
                          date = dateNew;
                          select();
                        }
                      });
                    },
                    child: Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 48,
                        vertical: 10,
                      ),
                      margin: EdgeInsets.symmetric(horizontal: 10),
                      decoration: BoxDecoration(
                        color: Constants.darkAccent,
                        borderRadius: BorderRadius.horizontal(
                          left: Radius.circular(10),
                          right: Radius.circular(10),
                        ),
                      ),
                      child: Center(
                        child: Text(
                          Global.formatDate(
                              date: date.toString(),
                              inputPattern: Global.DATETIME_DATABASE,
                              outputPattern: Global.DATETIME_SHOW_DATE),
                          style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 10),
              child: Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Text("Total Transaksi",
                              style: TextStyle(fontWeight: FontWeight.bold)),
                          Expanded(
                              child: Align(
                                  alignment: Alignment.centerRight,
                                  child: Text(
                                      Global.delimeter(
                                          number: totalTransaction.toString()),
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold)))),
                        ],
                      ),
                      SizedBox(height: 5),
                      // Row(
                      //   children: [
                      //     Text("Total",
                      //         style: TextStyle(fontWeight: FontWeight.bold)),
                      //     Expanded(
                      //         child: Align(
                      //             alignment: Alignment.centerRight,
                      //             child: Text(
                      //                 Global.delimeter(
                      //                     number: total.toString()),
                      //                 style: TextStyle(
                      //                     fontWeight: FontWeight.bold)))),
                      //   ],
                      // )
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 20),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                children: [
                  Align(
                      alignment: Alignment.center,
                      child: Text("Aktifitas",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.black26))),
                  Expanded(
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Container(
                        margin: EdgeInsets.only(left: 10),
                        decoration: BoxDecoration(
                          color: Constants.darkAccent,
                          borderRadius: BorderRadius.horizontal(
                            left: Radius.circular(15),
                            right: Radius.circular(15),
                          ),
                        ),
                        child: IconButton(
                            icon:
                                Icon(Icons.add, color: Colors.white, size: 20),
                            onPressed: () {
                              Global.materialNavigate(
                                      context, ContentOrder(datetime: date))
                                  .then((value) => select());
                            }),
                      ),
                    ),
                  )
                ],
              ),
            ),
            if (_order.length > 0) ...[
              ListView.builder(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: _order.length,
                itemBuilder: (context, index) {
                  String detail = "";
                  if (_order[index].statusConfirm == "0")
                    detail = "\n[BELUM KONFIRMASI]\n";
                  else if (_order[index].statusConfirm == "1")
                    detail = "\n[SUDAH KONFIRMASI]\n";
                  else if (_order[index].statusConfirm == "2")
                    detail = "\n[ON PROSES]\n";
                  else if (_order[index].statusConfirm == "3")
                    detail = "\n[ON  KIRIM]\n";
                  else if (_order[index].statusConfirm == "4")
                    detail = "\n[SUDAH KONFIRMASI]\n";

                  _order[index].detail.forEach((data) {
                    OrderDetail orderDetail = OrderDetail.fromJson(data);
                    detail += " Customer   : " +
                        orderDetail.customer +
                        "\n Telp  : " +
                        orderDetail.telp +
                        "\n Alamat  : " +
                        orderDetail.alamat +
                        "     " +
                        "\n  Pesenan  : " +
                        orderDetail.desc +
                        "";
                  });

                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      child: ListTile(
                        onTap: () {
                          if (_order[index].statusConfirm == "0")
                            _dialogAction(_order[index]);
                        },
                        title: Row(
                          children: [
                            Text(
                              "NO Transaksi " +
                                  Global.delimeter(number: _order[index].id),
                              style: TextStyle(fontWeight: FontWeight.bold),
                            )
                          ],
                        ),
                        subtitle: Text(detail),
                      ),
                    ),
                  );
                },
              )
            ] else ...[
              SizedBox(height: 80),
              Image.asset(
                'assets/file-storage.png',
                width: 100.0,
                fit: BoxFit.cover,
              ),
              SizedBox(height: 10),
              Text("Tidak ada data")
            ]
          ],
        ),
      ))),
    );
  }

  Future<void> select() async {
    totalTransaction = 0;
    total = 0;
    _order = [];

    final response = API
        .fromJson(await Order.select(context: context, date: date.toString()));
    if (response.success) {
      response.data.forEach((data) {
        Order orderData = Order.fromJson(data);
        totalTransaction++;
        total += int.parse(orderData.total);
        _order.add(orderData);
      });
    }
    // else Dialogs.showSimpleText(context: context, text: response.message);

    setState(() {});
  }

// Future<void> fetchData() async {
//  // fetchProduct;

//  await fetchCustomer();
// }

//   Future<void> fetchCustomer() async {
//     final response = API
//         .fromJson(await Customer.select(context: context, showLoading: false));
//     if (response.success) {
//       List<String> offline = [];
//       response.data.forEach((data) {
//         offline.add(jsonEncode(data));
//       });
//       Global.setSharedList(key: Prefs.PREFS_OFFLINE_CUSTOMER, value: offline);
//     }
//   }

  Future<void> delete(Order _order) async {
    final response =
        API.fromJson(await Order.delete(context: context, code: _order.id));
    if (response.success) {
      Dialogs.hideDialog(context: context);
      select();
    } else
      Dialogs.showSimpleText(context: context, text: response.message);
  }

  Future<void> confirm(Order _order) async {
    final response =
        API.fromJson(await Order.confirm(context: context, code: _order.id));
    if (response.success) {
      Dialogs.hideDialog(context: context);
      select();
    } else
      Dialogs.showSimpleText(context: context, text: response.message);
  }

  void _dialogAction(Order _order) {
    showDialog(
        context: context,
        builder: (context) => StatefulBuilder(builder: (context, setState) {
              return AlertDialog(
                elevation: 24,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(5))),
                content: Container(
                  width: 150,
                  height: 100,
                  child: Center(
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        GestureDetector(
                          onTap: () {
                            Global.materialNavigate(
                                    context, ContentOrder(order: _order))
                                .then((value) {
                              Dialogs.hideDialog(context: context);
                              select();
                            });
                          },
                          child: Image.asset(
                            'assets/edit.png',
                            width: 50.0,
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.symmetric(horizontal: 35),
                          child: GestureDetector(
                            onTap: () {
                              Dialogs.showYesNo(
                                  context: context,
                                  text:
                                      "Apakah yakin konfirmasi data pembelian?",
                                  action: (result) {
                                    if (result) {
                                      confirm(_order);
                                    }
                                  });
                            },
                            child: Image.asset(
                              'assets/document.png',
                              width: 50.0,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            Dialogs.showYesNo(
                                context: context,
                                text: "Apakah yakin menghapus data pembelian?",
                                action: (result) {
                                  if (result) {
                                    delete(_order);
                                  }
                                });
                          },
                          child: Image.asset(
                            'assets/delete.png',
                            width: 50.0,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }));
  }
}
