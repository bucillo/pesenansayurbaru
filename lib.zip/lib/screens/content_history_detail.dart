import 'dart:convert';

import 'package:bucil/models/api.dart';
import 'package:bucil/models/auth.dart';
import 'package:bucil/models/invoice.dart';
import 'package:bucil/models/product.dart';
import 'package:bucil/models/sales.dart';
import 'package:bucil/util/const.dart';
import 'package:bucil/util/dialog.dart';
import 'package:bucil/util/global.dart';
import 'package:flutter/material.dart';
import '../bluetooth_printer.dart';

//PAGE HISTORY DETAIL
class ContentHistoryDetail extends StatefulWidget {
  final Sales sales;

  const ContentHistoryDetail({Key key, this.sales}) : super(key: key);

  @override
  _ContentHistoryDetailState createState() => _ContentHistoryDetailState();
}

class _ContentHistoryDetailState extends State<ContentHistoryDetail> {
  int grandtotal = 0;
  List<SalesDetail> salesdetails = [];

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () async {
      refresh();
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.sync, color: Constants.lightNavbarBG),
              onPressed: null,
            ),
          ],
          backgroundColor: Constants.lightNavbarBG,
          title: Center(
              child: Text(
            "Detil Riwayat",
            style: TextStyle(color: Constants.lightAccent),
          ))),
      body: _content(),
    ));
  }

  Widget _content() {
    return Column(
      children: <Widget>[
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[detail()],
            ),
          ),
        ),
        footer(),
        footer2(),
      ],
    );
  }

  Widget footer() {
    return Column(
      children: <Widget>[
        Container(
          padding: EdgeInsets.all(15),
          color: Constants.darkAccent,
          width: double.infinity,
          height: 70,
          child: Row(
            children: <Widget>[
              Expanded(
                flex: 3,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      "Total:",
                      style: TextStyle(color: Colors.white, fontSize: 12),
                    ),
                    Text(
                      "Rp. " + Global.delimeter(number: grandtotal.toString()),
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold),
                    )
                  ],
                ),
              ),
              Expanded(
                flex: 1,
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Icon(
                    Icons.chevron_right,
                    color: Constants.darkAccent,
                  ),
                ),
              )
            ],
          ),
        ),
      ],
    );
  }

  Widget footer2() {
    return Column(
      children: <Widget>[
        Container(
          padding: EdgeInsets.all(15),
          color: Constants.darkAccent,
          width: double.infinity,
          height: 120,
          child: Row(
            children: <Widget>[
              Expanded(
                flex: 7,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      "Discount:",
                      style: TextStyle(color: Colors.white, fontSize: 12),
                    ),
                    Text(
                      "Rp. " +
                          Global.delimeter(
                              number: widget.sales.discountNominal),
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold),
                    ),
                    Text(""),
                    Text(
                      "Grand total",
                      style: TextStyle(color: Colors.white, fontSize: 12),
                    ),
                    Text(
                      "Rp. " +
                          Global.delimeter(number: widget.sales.grandtotal),
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold),
                    )
                  ],
                ),
              ),
              Expanded(
                flex: 1,
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Icon(
                    Icons.chevron_right,
                    color: Constants.darkAccent,
                  ),
                ),
              )
            ],
          ),
        ),
        InkWell(
          onTap: () {
            Dialogs.showReprint(
                context: context,
                action: (type) async {
                  List<String> offline = Global.getSharedList(key: Prefs.PREFS_OFFLINE_PRODUCT);
                  List<InvoiceDetail> invoiceDetails = [];
                  salesdetails.forEach((data) {
                    
                    List<dynamic> productPrint = [];
                    print("LENGTH: " + offline.length.toString());
                    for (int i = 0; i < offline.length; i++) {
                      Product product = Product.fromJson(jsonDecode(offline[i]));
                      if(product.id == data.productId){
                        productPrint = product.productPrints;
                      }
                    }

                    InvoiceDetail invoiceDetail = InvoiceDetail(
                      itemName: data.productName,
                      price: data.price.toString(),
                      qty: data.qty.toString(),
                      notes: data.notes,
                      productPrints: productPrint,
                      detailSubtotal: data.total.toString(),
                    );
                    invoiceDetails.add(invoiceDetail);
                  });

                  //? check bluetooth nyala atau tidak
                  bool canPrint = await Printing().isBTEnabled();
                  // double change = double.parse(sales[index].changeTotal);
                  //todo check canprint
                  if (!canPrint) {
                    Dialogs.showSimpleText(
                        context: context,
                        text: 'Bluetooth belum dinyalakan. Print gagal');
                    return;
                  }
                  InvoiceHeader invoiceHeader = InvoiceHeader(
                      headerDiscPercent: widget.sales.discountPercent,
                      headerDiscValue: widget.sales.discountNominal,
                      headerSubtotal: widget.sales.subtotal,
                      headerTotal: widget.sales.subtotal,
                      payAmount: widget.sales.paymentTotal,
                      change: (int.parse(widget.sales.paymentTotal) -
                              (int.parse(widget.sales.subtotal) -
                                  int.parse(widget.sales.discountNominal)))
                          .toString(),
                      customerName: widget.sales.salesCustomerName,
                      customerAddress: widget.sales.salesCustomerAddress,
                      customerPhone: widget.sales.salesCustomerPhone,
                      keterangan: widget.sales.salestypeName,
                      keterangan2: widget.sales.salestypeName,
                      date: widget.sales.date);
                  Invoice invoice = Invoice(
                      code: 'nota #' + widget.sales.code,
                      invoiceHeader: invoiceHeader,
                      invoiceDetail: invoiceDetails,
                      footer: 'Copy Print');
                  if (type == 0) {
                    print('print Nota');
                    if (Printing().isPrinterInvAvailable()) {
                      Printing().printMultiple(
                          context, invoice, PrinterType.PRINTER_INVOICE);
                    }
                  } 
                  else if (type == 1) {
                    print('print Dapur');
                    if (Printing().isPrinterInvAvailable()) {
                      Printing().printMultiple(
                          context, invoice, PrinterType.PRINTER_KITCHEN);
                    }
                  } 
                  else if (type == 3) {
                    print('print Makanan');
                    Printing().printMultiple(context, invoice, PrinterType.PRINTER_FOOD, showLoading: false);
                  } 
                  else if (type == 4) {
                    print('print Minuman');
                    Printing().printMultiple(context, invoice, PrinterType.PRINTER_DRINK, showLoading: false);
                  } 
                  else if (type == 2) {
                    print('print Semua');
                    if (Printing().isPrinterInvAvailable() && canPrint) {
                      Printing().printMultiple(context, invoice, PrinterType.PRINTER_INVOICE);
                      if (Printing().isPrinterKitchenAvailable() && canPrint) {
                        Printing().printMultiple(context, invoice, PrinterType.PRINTER_KITCHEN);
                      }
                      Printing().printMultiple(context, invoice, PrinterType.PRINTER_FOOD, showLoading: false);
                      Printing().printMultiple(context, invoice, PrinterType.PRINTER_DRINK, showLoading: false);
                    }
                  }
                });
          },
          child: Container(
            padding: EdgeInsets.all(10),
            color: Colors.orange,
            width: double.infinity,
            height: 50,
            child: Align(
                alignment: Alignment.center,
                child: Text(
                  "PRINT ULANG",
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold),
                )),
          ),
        )
      ],
    );
  }

  Widget detail() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Divider(
          height: 1,
          color: Colors.grey,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          child: Text(
            "DETAIL",
          ),
        ),
        Divider(height: 1, color: Colors.grey),
        ListView.builder(
            itemCount: salesdetails.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (BuildContext context, int index) {
              return Container(
                padding: const EdgeInsets.all(10),
                color: Colors.white,
                child: Row(
                  children: <Widget>[
                    SizedBox(
                      height: 50,
                      width: 50,
                      child: Container(
                        color: Colors.orange,
                        child: Center(
                          child: Text(
                            Global.delimeter(
                                number: salesdetails[index].qty.toString()),
                            style: TextStyle(fontSize: 20, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      flex: 5,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(salesdetails[index].productName,
                              style: TextStyle(fontSize: 14)),
                          Text(
                              "Harga: Rp. " +
                                  Global.delimeter(
                                      number:
                                          salesdetails[index].price.toString()),
                              style: TextStyle(
                                  fontSize: 12, fontStyle: FontStyle.italic)),
                          if (salesdetails[index].notes != null) ...[
                            Text(salesdetails[index].notes,
                                style: TextStyle(
                                    fontSize: 12, fontStyle: FontStyle.italic))
                          ]
                        ],
                      ),
                    )
                  ],
                ),
              );
            }),
      ],
    );
  }

  Future<void> refresh() async {
    final response = API.fromJson(await SalesDetail.get(context: context, salesId: widget.sales.id));

    if (response.success) {
      response.data.forEach((data) {
        SalesDetail salesDetail = new SalesDetail.fromJson(data);
        salesdetails.add(salesDetail);
        grandtotal += (salesDetail.price * salesDetail.qty).round();
      });
      setState(() {});
    } else {
      if (response.code == 401)
        Auth.logout(context);
      else
        Dialogs.showSimpleText(context: context, text: response.message);
    }
  }
}
