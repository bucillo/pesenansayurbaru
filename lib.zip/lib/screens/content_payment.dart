import 'dart:convert';

import 'package:bucil/models/api.dart';
import 'package:bucil/models/cart.dart';
import 'package:bucil/models/cart_detail.dart';
import 'package:bucil/models/paymentmethod.dart';
import 'package:bucil/models/sales.dart';
import 'package:bucil/models/salestype.dart';
import 'package:bucil/models/syncronize.dart';
import 'package:bucil/screens/content_success_pay.dart';
import 'package:bucil/util/const.dart';
import 'package:bucil/util/currency_format.dart';
import 'package:bucil/util/dialog.dart';
import 'package:bucil/util/global.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:bucil/models/invoice.dart';
import 'package:bucil/bluetooth_printer.dart';

//PAGE PAYMENT
class ContentPayment extends StatefulWidget {
  final Salestype salestype_selected;
  final String customer;
  final String customerPhone;
  final String customerAddress;
  final String customer2;
  final Salestype sales_typenama;

  const ContentPayment(
      {Key key, this.salestype_selected, this.customer, this.customerPhone = "", this.customerAddress = "", this.sales_typenama, this.customer2})
      : super(key: key);

  @override
  _ContentPaymentState createState() => _ContentPaymentState();
}

class _ContentPaymentState extends State<ContentPayment> {
  bool setAuto = true;
  bool logout = false;
  bool _isDisposed = false;
  int total = 0;
  double total_item = 0;
  int total_discount = 0;
  int grandtotal = 0;
  TextEditingController _paymentController = TextEditingController();
  TextEditingController _discountPercentageController =
      new TextEditingController();
  TextEditingController _discountNominalController =
      new TextEditingController();
  List<CartDetail> cart = [];
  List<Paymentmethod> paymentmethod = [];
  Paymentmethod paymentmethod_selected;
  double change;

  @override
  void initState() {
    super.initState();
    _discountPercentageController.text = "0";
    _discountNominalController.text = "0";
    refresh();
  }

  @override
  void dispose() {
    super.dispose();
    _isDisposed = true;
    _paymentController.dispose();
    _discountNominalController.dispose();
    _discountPercentageController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.sync, color: Constants.lightNavbarBG),
              onPressed: null,
            ),
          ],
          backgroundColor: Constants.lightNavbarBG,
          title: Center(
              child: Text(
            "Pembayaran",
            style: TextStyle(color: Constants.lightAccent),
          ))),
      body: _content(),
    ));
  }

  Widget _content() {
    return Column(
      children: <Widget>[
        header(),
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[discount(), payment()],
            ),
          ),
        ),
        submit()
      ],
    );
  }

  Widget header() {
    return Container(
      padding: EdgeInsets.all(20),
      color: Constants.darkAccent,
      alignment: Alignment.center,
      height: 100,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            "Total:",
            style: TextStyle(color: Colors.white, fontSize: 12),
          ),
          Text(
            "Rp. " + Global.delimeter(number: grandtotal.toString()),
            style: TextStyle(
                color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
          )
        ],
      ),
    );
  }

  Widget detail() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Divider(
          height: 1,
          color: Colors.grey,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          child: Text(
            "DETAIL",
          ),
        ),
        Divider(height: 1, color: Colors.grey),
        ListView.builder(
            itemCount: cart.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (BuildContext context, int index) {
              return Container(
                padding: const EdgeInsets.all(10),
                color: Colors.white,
                child: Row(
                  children: <Widget>[
                    SizedBox(
                      height: 50,
                      width: 50,
                      child: Container(
                        color: Colors.orange,
                        child: Center(
                          child: Text(
                            Global.delimeter(
                                number: cart[index].qty.toString()),
                            style: TextStyle(fontSize: 20, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      flex: 5,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(cart[index].name,
                              style: TextStyle(fontSize: 14)),
                          Text(
                              "Harga: Rp. " +
                                  Global.delimeter(
                                      number: cart[index].price.toString()),
                              style: TextStyle(
                                  fontSize: 12, fontStyle: FontStyle.italic))
                        ],
                      ),
                    )
                  ],
                ),
              );
            }),
      ],
    );
  }

  Widget discount() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Divider(
          height: 1,
          color: Colors.grey,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          child: Text(
            "DISKON",
          ),
        ),
        Divider(height: 1, color: Colors.grey),
        Container(
          color: Colors.white,
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  Expanded(
                    flex: 2,
                    child: Text("Persentase:"),
                  ),
                  Expanded(
                    flex: 1,
                    child: TextFormField(
                      controller: _discountPercentageController,
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        CurrencyFormat()
                      ],
                      decoration: InputDecoration(
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.lightBlue),
                        ),
                      ),
                      onChanged: (_) {
                        if (_discountPercentageController.text == "") {
                          _discountPercentageController.text = "0";
                          _discountPercentageController.selection =
                              TextSelection.fromPosition(TextPosition(
                                  offset: _discountPercentageController
                                      .text.length));
                        }
                        if (int.parse(_discountPercentageController.text
                                .replaceAll(".", "")) >
                            100) _discountPercentageController.text = "100";
                        total_discount =
                            (int.parse(_discountPercentageController.text) *
                                    total /
                                    100)
                                .ceil();
                        _discountNominalController.text =
                            Global.delimeter(number: total_discount.toString());
                        grandtotal = total - total_discount;

                        setState(() {});
                      },
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: Text(
                      "%",
                      textAlign: TextAlign.left,
                    ),
                  ),
                  Expanded(flex: 3, child: Container())
                ],
              ),
              Row(
                children: <Widget>[
                  Expanded(
                    flex: 2,
                    child: Text("Nominal:"),
                  ),
                  Expanded(
                    flex: 2,
                    child: TextFormField(
                      controller: _discountNominalController,
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        CurrencyFormat()
                      ],
                      decoration: InputDecoration(
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.lightBlue),
                        ),
                      ),
                      onChanged: (_) {
                        if (_discountNominalController.text == "") {
                          _discountNominalController.text = "0";
                          _discountNominalController.selection =
                              TextSelection.fromPosition(TextPosition(
                                  offset:
                                      _discountNominalController.text.length));
                        }
                        if (int.parse(_discountNominalController.text
                                .replaceAll(".", "")) >
                            total)
                          _discountNominalController.text =
                              Global.delimeter(number: total.toString());
                        total_discount = int.parse(_discountNominalController
                            .text
                            .replaceAll(".", ""));
                        int _discountPercent =
                            (total_discount / total * 100).ceil();
                        _discountPercentageController.text = Global.delimeter(
                            number: _discountPercent.toString());
                        grandtotal = total - total_discount;

                        setState(() {});
                      },
                    ),
                  ),
                  Expanded(flex: 3, child: Container())
                ],
              )
            ],
          ),
        )
      ],
    );
  }

  Widget payment() {
    if (setAuto) {
      setState(() {
        _paymentController.text =
            Global.delimeter(number: grandtotal.toString());
        setAuto = false;
      });
    }
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        if (paymentmethod.length > 0) ...[
          Divider(
            height: 1,
            color: Colors.grey,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            child: Text(
              "METODE PEMBAYARAN",
            ),
          ),
          Divider(height: 1, color: Colors.grey),
          SizedBox(
            height: 80,
            child: Container(
              color: Colors.white,
              child: ListView.builder(
                padding: EdgeInsets.symmetric(horizontal: 10),
                itemCount: paymentmethod.length,
                scrollDirection: Axis.horizontal,
                itemBuilder: (BuildContext context, int index) {
                  return Center(
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          _paymentController.text =
                              Global.delimeter(number: grandtotal.toString());
                          paymentmethod_selected = paymentmethod[index];
                        });
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(5)),
                          border: Border.all(color: Constants.darkAccent),
                          color: (paymentmethod_selected.id ==
                                  paymentmethod[index].id)
                              ? Constants.darkAccent
                              : null,
                        ),
                        padding: EdgeInsets.all(15),
                        margin: EdgeInsets.all(5),
                        child: Text(
                          paymentmethod[index].name,
                          style: TextStyle(
                            color: (paymentmethod_selected.id ==
                                    paymentmethod[index].id)
                                ? Colors.white
                                : Constants.darkAccent,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ] else
          Container(),
        Divider(
          height: 1,
          color: Colors.grey,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          child: Text(
            "JUMLAH DIBAYAR",
          ),
        ),
        Divider(height: 1, color: Colors.grey),
        Container(
          color: Colors.white,
          child: Column(
            children: <Widget>[
              Container(
                  padding: EdgeInsets.only(left: 20),
                  child: TextFormField(
                    controller: _paymentController,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                      CurrencyFormat()
                    ],
                    enabled:
                        (paymentmethod_selected.type == "0") ? true : false,
                  )),
              SizedBox(height: 10),
              suggestion(),
              if (paymentmethod_selected.type == "1") ...[
                Container(
                  color: Colors.white,
                  height: 50,
                )
              ]
            ],
          ),
        )
      ],
    );
  }

  Widget suggestion() {
    int value1 = grandtotal;
    int value2 = 0;
    int value3 = 0;
    int value4 = 0;
    int value5 = 0;
    int value6 = 0;

    while (value2 < grandtotal) {
      value2 += 5000;
    }
    while (value3 < grandtotal) {
      value3 += 10000;
    }
    while (value4 < grandtotal) {
      value4 += 20000;
    }
    while (value5 < grandtotal) {
      value5 += 50000;
    }
    while (value6 < grandtotal) {
      value6 += 100000;
    }

    return GridView.count(
      padding: EdgeInsets.symmetric(horizontal: 15),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 3,
      crossAxisCount: 2,
      children: <Widget>[
        moneyField(value1),
        if (paymentmethod_selected.type == "0") ...[
          if (value2 != value1) moneyField(value2),
          if (value3 != value1 && value3 != value2) moneyField(value3),
          if (value4 != value1 && value4 != value2 && value4 != value3)
            moneyField(value4),
          if (value5 != value1 &&
              value5 != value2 &&
              value5 != value3 &&
              value5 != value4)
            moneyField(value5),
          if (value6 != value1 &&
              value6 != value2 &&
              value6 != value3 &&
              value6 != value4 &&
              value6 != value5)
            moneyField(value6),
        ]
      ],
    );
  }

  Widget submit() {
    return Container(
      color: Colors.white,
      child: InkWell(
        onTap: () async {
          FocusScope.of(context).requestFocus(new FocusNode());
          if (_paymentController.text == "") {
            Dialogs.showSimpleText(
                context: context, text: "Pembayaran kurang dari total");
          } else {
            if (int.parse(
                    Global.unformatNumber(number: _paymentController.text)) <
                grandtotal) {
              Dialogs.showSimpleText(
                  context: context, text: "Pembayaran kurang dari total");
            } else
              actionSave();
          }
        },
        child: Container(
          margin: EdgeInsets.only(top: 30),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20), topRight: Radius.circular(20)),
            color: Constants.darkAccent,
          ),
          width: double.infinity,
          padding: EdgeInsets.all(20),
          child: Center(
            child: Text(
              "BAYAR",
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: Colors.white),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> actionSave() async {
    List<SalesDetail> salesdetail = [];
    List<PaymentDetail> paymentdetail = [];
    List<InvoiceDetail> invoiceDetails = [];

    List<String> currentCartDetail = Global.getSharedList(key: Prefs.PREFS_CART_DETAIL);
    currentCartDetail.forEach((data) {
      CartDetail cartDetail = CartDetail.fromJson(jsonDecode(data));
      salesdetail.add(SalesDetail(
          productId: cartDetail.product,
          productName: cartDetail.name,
          price: cartDetail.price,
          qty: cartDetail.qty,
          total: (cartDetail.price * cartDetail.qty).round(),
          notes: cartDetail.notes));
      InvoiceDetail invoiceDetail = InvoiceDetail(
        itemName: cartDetail.name,
        price: cartDetail.price.toString(),
        qty: cartDetail.qty.toString(),
        detailSubtotal: (cartDetail.price * cartDetail.qty).toString(),
        notes: cartDetail.notes,
        productPrints: cartDetail.productPrints
      );
      invoiceDetails.add(invoiceDetail);
    });

    //? get kembalian
    change = double.parse(Global.unformatNumber(number: _paymentController.text)) - grandtotal;

    paymentdetail.add(PaymentDetail(
        paymentmethodId: paymentmethod_selected.id,
        payment: double.parse(
            Global.unformatNumber(number: _paymentController.text)),
        changepayment: change));

    String offlinecode = Global.getShared(key: Prefs.PREFS_USER_STORE_ID) +
        md5
            .convert(utf8.encode(Global.getShared(key: Prefs.PREFS_USER_TOKEN) +
                Global.getCurrentDate(format: Global.DATETIME_NOSPACE)))
            .toString()
            .substring(0, 12);
    String date = Global.getCurrentDate(format: Global.DATETIME_DATABASE);

    final response = API.fromJson(await Sales.insert(
        context: context,
        customerName: widget.customer,
        customerAddress: widget.customerAddress,
        customerPhone: widget.customerPhone,
        salestype: widget.salestype_selected.id,
   //     sales_typenama: widget.salestype_selected.name,
        offlinecode: offlinecode,
        date: date,
        subtotal: total,
        discountPercent: int.parse(
            Global.unformatNumber(number: _discountPercentageController.text)),
        discountNominal: int.parse(
            Global.unformatNumber(number: _discountNominalController.text)),
        salesDetail: salesdetail,
        paymentDetail: paymentdetail));

    InvoiceHeader invoiceHeader = InvoiceHeader(
      customerName: widget.customer,
      customerAddress: widget.customerAddress,
      customerPhone: widget.customerPhone,
      keterangan: widget.salestype_selected.id,
      keterangan2: widget.salestype_selected.name,
   //   keterangan3: widget.invoice.,
      date: date,
      headerDiscPercent: _discountPercentageController.text,
      headerDiscValue:
          Global.unformatNumber(number: _discountNominalController.text),
      headerSubtotal: total.toString(),
      payAmount: Global.unformatNumber(number: _paymentController.text),
      headerTotal: total.toString(),
      change: change.toString(),
    );

    Invoice invoice = Invoice(
        code: 'nota #' + offlinecode,
        invoiceHeader: invoiceHeader,
        invoiceDetail: invoiceDetails,
        footer: '** LUNAS **');

    bool isBTEnabled = false;
    bool haveShift = true;
    bool canPrint = false;
    if (response.success) {
      isBTEnabled = true;
      canPrint = true;
    } 
    else {
      if (Global.contains(textData: response.message.toLowerCase(), textSearch: "shift")) {
        haveShift = false;
        if (Global.getShared(key: Prefs.PREFS_PENDING_SHIFT, defaults: "") != "") {
          final response = API.fromJson(await Syncronize.syncShift(context: context, showLoading: false));
          if (response.success) actionSave();
        } 
        else Dialogs.showSimpleText(context: context, text: response.message);
      } 
      else {
        canPrint = true;
        Syncronize.addPendingSales(
            customerName: widget.customer,
            customerAddress: widget.customerAddress,
            customerPhone: widget.customerPhone,
            salestype: widget.salestype_selected.id,
            offlinecode: offlinecode,
            date: date,
            subtotal: total,
            discountPercent: int.parse(Global.unformatNumber(
                number: _discountPercentageController.text)),
            discountNominal: int.parse(
                Global.unformatNumber(number: _discountNominalController.text)),
            salesDetail: salesdetail,
            paymentDetail: paymentdetail);
      }
    }

    print(json.encode(invoice));

    if (canPrint) {
      //? check bluetooth nyala atau tidak
      isBTEnabled = await _isBTEnabled();
      if (!isBTEnabled) successTransaction();
      else printAll(invoice, change: change, haveShift: haveShift);
    }
  }

  void printAll(Invoice invoice, {double change, bool haveShift}) {
    if (Printing().isPrinterInvAvailable()) {
      Printing().printMultiple(context, invoice, PrinterType.PRINTER_INVOICE,
          failedAction: () {
            tryReprint(invoice, change: change, haveShift: haveShift);
          }, 
          successAction: () {
            if (!Printing().isPrinterKitchenAvailable()) {
              successTransaction();
            } 
            else {
              Printing().printMultiple(context, invoice, PrinterType.PRINTER_KITCHEN, 
                failedAction: () { tryReprint(invoice, change: change, haveShift: haveShift, printerType: 'dapur'); }, 
                successAction: () { successTransaction(); }
            );
          }
        }
      );
    } 
    else if (haveShift) {
      successTransaction();
    }

    Printing().printMultiple(context, invoice, PrinterType.PRINTER_FOOD, failedAction: (){}, successAction: (){}, showLoading: false );
    Printing().printMultiple(context, invoice, PrinterType.PRINTER_DRINK, failedAction: (){}, successAction: (){}, showLoading: false );
  }

  void tryReprint(Invoice invoice,
      {double change, bool haveShift, String printerType = 'nota'}) {
    Dialogs.showReprint(
        title: 'Cetak $printerType gagal',
        context: context,
        allowBack: false,
        action: (type) async {
          Navigator.pop(context);
          if (type == 0) {
            print('Print Nota');
            if (!Printing().isPrinterInvAvailable()) {
              Dialogs.showSimpleText(
                  context: context,
                  text: 'Cetak nota gagal. Printer invoice belum disetting.');
              return;
            }
            Printing()
                .printMultiple(context, invoice, PrinterType.PRINTER_INVOICE,
                    failedAction: () {
              tryReprint(invoice, change: change, haveShift: haveShift);
            }, successAction: () {
              successTransaction();
            });
          } 
          else if (type == 1) {
            print('Print Dapur');
            if (!Printing().isPrinterKitchenAvailable()) {
              Dialogs.showSimpleText(
                  context: context,
                  text:'Cetak checker dapur gagal. Printer dapur belum disetting.');
              return;
            }
            Printing().printMultiple(context, invoice, PrinterType.PRINTER_KITCHEN,
                    failedAction: () {tryReprint(invoice, change: change, haveShift: haveShift);}, successAction: () {
              successTransaction();
            });
          } 
          else if (type == 2) {
            print('Print Semua');
            printAll(invoice, change: change, haveShift: haveShift);
          } 
          else if (type == 3) {
            //* lewati tanpa melakukan print
            successTransaction();
          }
        },
        skipButton: true);
    // showDialog(
    //     context: context,
    //     barrierDismissible: false,
    //     builder: (context) {
    //       return Column(
    //         children: <Widget>[
    //           Container(
    //             child: InkWell(
    //               child: Text('Print invoice'),
    //               onTap: () {},
    //             ),
    //           ),
    //           Container(
    //             child: InkWell(
    //               child: Text('Print dapur'),
    //               onTap: () {},
    //             ),
    //           ),
    //           Container(
    //             child: InkWell(
    //               child: Text('Print semua'),
    //               onTap: () {},
    //             ),
    //           ),
    //           Container(
    //             child: InkWell(
    //               child: Text('Lewati'),
    //               onTap: () {
    //               },
    //             ),
    //           ),
    //         ],
    //       );
    //     });
  }

  void successTransaction() {
    Cart.clearCart();
    Global.materialNavigateReplace(
      context,
      ContentSuccessPay(
        method: paymentmethod_selected.name,
        change: change,
      ),
    );
  }

  Future<bool> _isBTEnabled() async {
    const platform = const MethodChannel("printer");
    bool _isBluetoothEnabled = false;
    if (_isDisposed) return _isBluetoothEnabled;
    try {
      bool tempBool = await platform.invokeMethod('isBluetoothEnabled');
      setState(() {
        _isBluetoothEnabled = tempBool;
        // _isLoading = false;
      });
      print('_isBluetoothEnabled : $_isBluetoothEnabled');
    } catch (e) {
      setState(() {
        _isBluetoothEnabled = false;
      });
    }
    return _isBluetoothEnabled;
  }

  Widget moneyField(int value) {
    return InkWell(
      onTap: () {
        setState(() {
          _paymentController.text = Global.delimeter(number: value.toString());
        });
      },
      child: Container(
        width: double.infinity,
        height: 10,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(5)),
          border: Border.all(color: Constants.darkAccent),
          color: null,
        ),
        margin: EdgeInsets.symmetric(horizontal: 5, vertical: 5),
        padding: EdgeInsets.all(15),
        child: Center(
          child: (value == grandtotal)
              ? Text("Uang Pas", style: TextStyle(color: Constants.darkAccent))
              : Text("Rp. " + Global.delimeter(number: value.toString()),
                  style: TextStyle(color: Constants.darkAccent)),
        ),
      ),
    );
  }

  Future<void> refresh() async {
    List<String> currentCartDetail = [];
    cart = [];
    total = 0;
    total_item = 0;
    currentCartDetail = Global.getSharedList(key: Prefs.PREFS_CART_DETAIL);
    currentCartDetail.forEach((data) {
      CartDetail cartDetail = CartDetail.fromJson(jsonDecode(data));
      total += (cartDetail.price * cartDetail.qty).round();
      total_item += cartDetail.qty;
      cart.add(cartDetail);
    });
    grandtotal = total;

    logout = false;
    await fetchPaymentmethod();

    if (mounted) setState(() {});
  }

  Future<void> fetchPaymentmethod() async {
    List<String> offline = [];
    offline = Global.getSharedList(key: Prefs.PREFS_OFFLINE_PAYMENTMETHOD);
    bool selected = false;
    for (int i = 0; i < offline.length; i++) {
      if (!selected) {
        paymentmethod_selected = Paymentmethod.fromJson(jsonDecode(offline[i]));
        selected = true;
      }
      paymentmethod.add(Paymentmethod.fromJson(jsonDecode(offline[i])));
    }
  }
}
