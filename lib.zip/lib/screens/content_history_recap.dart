import 'package:bucil/models/api.dart';
import 'package:bucil/models/auth.dart';
import 'package:bucil/models/shift.dart';
import 'package:bucil/screens/content_recap_review.dart';
import 'package:bucil/util/const.dart';
import 'package:bucil/util/global.dart';
import 'package:flutter/material.dart';

//PAGE HISTORY RECAP
class ContentHistoryRecap extends StatefulWidget {
  @override
  _ContentHistoryRecapState createState() => _ContentHistoryRecapState();
}

class _ContentHistoryRecapState extends State<ContentHistoryRecap> {
  bool logout = false;
  List<Shift> shift = [];
  DateTime dateStart = DateTime.now();
  DateTime dateEnd = DateTime.now();
  TextEditingController start = TextEditingController();
  TextEditingController end = TextEditingController();

  @override
  void initState() {
    super.initState();
    start.text = Global.formatDate(
        date: dateStart.toString(),
        inputPattern: Global.DATETIME_DATABASE,
        outputPattern: Global.DATETIME_SHOW_DATE);
    end.text = Global.formatDate(
        date: dateStart.toString(),
        inputPattern: Global.DATETIME_DATABASE,
        outputPattern: Global.DATETIME_SHOW_DATE);
    Future.delayed(Duration.zero, () async {
      refresh();
    });
  }

  @override
  void dispose() {
    super.dispose();
    start.dispose();
    end.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
          backgroundColor: Constants.lightNavbarBG,
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.sync, color: Constants.lightNavbarBG),
              onPressed: null,
            ),
          ],
          title: Center(
              child: Text(
            "Riwayat Shift",
            style: TextStyle(color: Constants.lightAccent),
          ))),
      body: content(),
    ));
  }

  Widget content() {
    return Container(
      height: double.infinity,
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[_filter(), _content()],
      ),
    );
  }

  Widget _filter() {
    return Container(
      color: Colors.white,
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                flex: 1,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: InkWell(
                    onTap: () {
                      Global.selectDate(context, initialDate: dateStart)
                          .then((date) {
                        dateStart = date;
                        start.text = Global.formatDate(
                            date: dateStart.toString(),
                            inputPattern: Global.DATETIME_DATABASE,
                            outputPattern: Global.DATETIME_SHOW_DATE);
                      });
                    },
                    child: TextField(
                      decoration: InputDecoration(
                          hintText: "Tanggal Awal",
                          labelText: "Tanggal Awal",
                          border: OutlineInputBorder()),
                      enabled: false,
                      controller: start,
                    ),
                  ),
                ),
              ),
              Expanded(
                flex: 1,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: InkWell(
                    onTap: () {
                      Global.selectDate(context, initialDate: dateEnd)
                          .then((date) {
                        dateEnd = date;
                        end.text = Global.formatDate(
                            date: dateEnd.toString(),
                            inputPattern: Global.DATETIME_DATABASE,
                            outputPattern: Global.DATETIME_SHOW_DATE);
                      });
                    },
                    child: TextField(
                      decoration: InputDecoration(
                          hintText: "Tanggal Akhir",
                          labelText: "Tanggal Akhir",
                          border: OutlineInputBorder()),
                      enabled: false,
                      controller: end,
                    ),
                  ),
                ),
              ),
            ],
          ),
          Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 50),
            child: FlatButton(
              child: Text(
                "Tampilkan",
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
              ),
              shape: new RoundedRectangleBorder(
                borderRadius: new BorderRadius.circular(10),
                side: BorderSide(color: Constants.darkAccent),
              ),
              color: Constants.darkAccent,
              textColor: Colors.white,
              onPressed: refresh,
            ),
          ),
          SizedBox(height: 5),
          Divider(height: 1, thickness: 3)
        ],
      ),
    );
  }

  Widget _content() {
    if (shift.length == 0) {
      return Expanded(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Icon(Icons.shopping_basket, size: 150, color: Colors.grey),
            Text(
              "Tidak ada shift",
              style: TextStyle(color: Colors.grey),
            )
          ],
        ),
      );
    } else {
      return Expanded(
        child: ListView.builder(
            padding: EdgeInsets.only(top: 10, left: 10, right: 10),
            itemCount: shift.length,
            shrinkWrap: true,
            itemBuilder: (BuildContext context, int index) {
              if (true) {
                return InkWell(
                  onTap: () {
                    getDetail(index);
                  },
                  child: Card(
                    elevation: 3,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Container(
                            child: Text(
                              shift[index].usersName,
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 18),
                            ),
                          ),
                          SizedBox(height: 8),
                          Container(
                            child: Text(
                              "Jam buka: " +
                                  Global.formatDate(
                                      date: shift[index].dateOpenShift,
                                      outputPattern:
                                          Global.DATETIME_SHOW_DETAIL),
                              style: TextStyle(
                                  fontStyle: FontStyle.italic, fontSize: 14),
                            ),
                          ),
                          Container(
                            child: Text(
                              "Jam tutup: " +
                                  Global.formatDate(
                                      date: shift[index].dateClosingShift,
                                      outputPattern:
                                          Global.DATETIME_SHOW_DETAIL),
                              style: TextStyle(
                                  fontStyle: FontStyle.italic, fontSize: 14),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }
            }),
      );
    }
  }

  Future<void> refresh() async {
    shift = [];
    final response = API.fromJson(await Shift.selectHistory(
        context: context,
        dateStart: Global.formatDate(
            date: dateStart.toString(),
            inputPattern: Global.DATETIME_DATABASE,
            outputPattern: Global.DATETIME_DATABASE_DATE),
        dateEnd: Global.formatDate(
            date: dateEnd.toString(),
            inputPattern: Global.DATETIME_DATABASE,
            outputPattern: Global.DATETIME_DATABASE_DATE)));

    if (response.success) {
      response.data.forEach((data) {
        shift.add(Shift.fromJson(data));
      });
    } else {
      if (response.code == 401) Auth.logout(context);
    }
    setState(() {});
  }

  Future<void> getDetail(int index) async {
    final response = API.fromJson(
        await Shift.selectDetail(context: context, id: shift[index].shiftId));

    if (response.success) {
      Global.materialNavigate(
          context,
          ContentRecapReview(
              data: response.data, cashier: shift[index].usersName));
    } else {
      if (response.code == 401) Auth.logout(context);
    }
    setState(() {});
  }
}
