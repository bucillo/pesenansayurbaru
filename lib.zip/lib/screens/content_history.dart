import 'package:bucil/models/api.dart';
import 'package:bucil/models/auth.dart';
import 'package:bucil/models/sales.dart';
import 'package:bucil/screens/content_history_detail.dart';
import 'package:bucil/util/const.dart';
import 'package:bucil/util/global.dart';
import 'package:flutter/material.dart';

//PAGE HISTORY
class ContentHistory extends StatefulWidget {
  @override
  _ContentHistoryState createState() => _ContentHistoryState();
}

class _ContentHistoryState extends State<ContentHistory> {
  bool logout = false;
  List<Sales> sales = [];
  DateTime dateStart = DateTime.now();
  DateTime dateEnd = DateTime.now();
  TextEditingController start = TextEditingController();
  TextEditingController end = TextEditingController();

  @override
  void initState() {
    super.initState();
    start.text = Global.formatDate(
        date: dateStart.toString(),
        inputPattern: Global.DATETIME_DATABASE,
        outputPattern: Global.DATETIME_SHOW_DATE);
    end.text = Global.formatDate(
        date: dateStart.toString(),
        inputPattern: Global.DATETIME_DATABASE,
        outputPattern: Global.DATETIME_SHOW_DATE);
    Future.delayed(Duration.zero, () async {
      refresh();
    });
  }

  @override
  void dispose() {
    super.dispose();
    start.dispose();
    end.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
          backgroundColor: Constants.lightNavbarBG,
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.sync, color: Constants.lightNavbarBG),
              onPressed: null,
            ),
          ],
          title: Center(
              child: Text(
            "Riwayat",
            style: TextStyle(color: Constants.lightAccent),
          ))),
      body: content(),
    ));
  }

  Widget content() {
    return Container(
      height: double.infinity,
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[_filter(), _content()],
      ),
    );
  }

  Widget _filter() {
    return Container(
      color: Colors.white,
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                flex: 1,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: InkWell(
                    onTap: () {
                      Global.selectDate(context, initialDate: dateStart)
                          .then((date) {
                        dateStart = date;
                        start.text = Global.formatDate(
                            date: dateStart.toString(),
                            inputPattern: Global.DATETIME_DATABASE,
                            outputPattern: Global.DATETIME_SHOW_DATE);
                      });
                    },
                    child: TextField(
                      decoration: InputDecoration(
                          hintText: "Tanggal Awal",
                          labelText: "Tanggal Awal",
                          border: OutlineInputBorder()),
                      enabled: false,
                      controller: start,
                    ),
                  ),
                ),
              ),
              Expanded(
                flex: 1,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: InkWell(
                    onTap: () {
                      Global.selectDate(context, initialDate: dateEnd)
                          .then((date) {
                        dateEnd = date;
                        end.text = Global.formatDate(
                            date: dateEnd.toString(),
                            inputPattern: Global.DATETIME_DATABASE,
                            outputPattern: Global.DATETIME_SHOW_DATE);
                      });
                    },
                    child: TextField(
                      decoration: InputDecoration(
                          hintText: "Tanggal Akhir",
                          labelText: "Tanggal Akhir",
                          border: OutlineInputBorder()),
                      enabled: false,
                      controller: end,
                    ),
                  ),
                ),
              ),
            ],
          ),
          Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 50),
            child: FlatButton(
              child: Text(
                "Tampilkan",
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
              ),
              shape: new RoundedRectangleBorder(
                borderRadius: new BorderRadius.circular(10),
                side: BorderSide(color: Constants.darkAccent),
              ),
              color: Constants.darkAccent,
              textColor: Colors.white,
              onPressed: refresh,
            ),
          ),
          SizedBox(height: 5),
          Divider(height: 1, thickness: 3)
        ],
      ),
    );
  }

  Widget _content() {
    if (sales.length == 0) {
      return Expanded(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Icon(Icons.shopping_basket, size: 150, color: Colors.grey),
            Text(
              "Tidak ada transaksi",
              style: TextStyle(color: Colors.grey),
            )
          ],
        ),
      );
    } else {
      return Expanded(
        child: ListView.builder(
            padding: EdgeInsets.only(top: 10, left: 10, right: 10),
            itemCount: sales.length,
            shrinkWrap: true,
            itemBuilder: (BuildContext context, int index) {
              if (true) {
                return InkWell(
                  onTap: () {
                    Global.cupertinoNavigate(
                        context, ContentHistoryDetail(sales: sales[index]));
                  },
                  child: Card(
                    elevation: 3,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Container(
                            child: Text(
                              "Nota  :  " + sales[index].code,
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 18),
                            ),
                          ),
                          Container(
                            child: Text(
                              "Payment :  " + sales[index].paymentmethodName,
                              style: TextStyle(
                                  fontStyle: FontStyle.italic, fontSize: 14),
                            ),
                          ),
                          Container(
                            child: Text(
                              "Type :  " + sales[index].salestypeName,
                              style: TextStyle(
                                  fontStyle: FontStyle.italic, fontSize: 14),
                            ),
                          ),
                          Container(
                            child: Text(
                              Global.formatDate(
                                  date: sales[index].date,
                                  outputPattern: Global.DATETIME_SHOW_DETAIL),
                              style: TextStyle(
                                  fontStyle: FontStyle.italic, fontSize: 14),
                            ),
                          ),
                          if (sales[index].salesCustomerName != "") ...[
                            Container(
                              child: Text(
                                "Pelanggan: " + sales[index].salesCustomerName,
                                style: TextStyle(
                                    fontStyle: FontStyle.italic, fontSize: 14),
                              ),
                            ),
                          ],
                          if (sales[index].salesCustomerAddress != "") ...[
                            Container(
                              child: Text(
                                "Alamat: " + sales[index].salesCustomerAddress,
                                style: TextStyle(
                                    fontStyle: FontStyle.italic, fontSize: 14),
                              ),
                            ),
                          ],
                          if (sales[index].salesCustomerPhone != "") ...[
                            Container(
                              child: Text(
                                "Telepon: " + sales[index].salesCustomerPhone,
                                style: TextStyle(
                                    fontStyle: FontStyle.italic, fontSize: 14),
                              ),
                            ),
                          ],
                          Container(
                            child: Text(
                              "Subtotal :  " +
                                  Global.delimeter(
                                      number: sales[index].subtotal),
                              style: TextStyle(
                                  fontStyle: FontStyle.italic, fontSize: 14),
                            ),
                          ),
                          Container(
                            child: Text(
                              "Discount :  " +
                                  Global.delimeter(
                                      number: sales[index].discountNominal),
                              style: TextStyle(
                                  fontStyle: FontStyle.italic, fontSize: 14),
                            ),
                          ),
                          Align(
                            alignment: Alignment.bottomRight,
                            child: Text(
                              "Rp. " +
                                  Global.delimeter(
                                      number: sales[index].grandtotal),
                              textAlign: TextAlign.end,
                              style: TextStyle(fontSize: 14),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                );
              }
            }),
      );
    }
  }

  Future<void> refresh() async {
    sales = [];
    final response = API.fromJson(await Sales.get(
        context: context,
        dateStart: Global.formatDate(
            date: dateStart.toString(),
            inputPattern: Global.DATETIME_DATABASE,
            outputPattern: Global.DATETIME_DATABASE_DATE),
        dateEnd: Global.formatDate(
            date: dateEnd.toString(),
            inputPattern: Global.DATETIME_DATABASE,
            outputPattern: Global.DATETIME_DATABASE_DATE)));

    if (response.success) {
      response.data.forEach((data) {
        sales.add(Sales.fromJson(data));
      });
    } else {
      if (response.code == 401) Auth.logout(context);
    }
    setState(() {});
  }
}
