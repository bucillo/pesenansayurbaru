import 'dart:convert';

import 'package:bucil/models/customer.dart';
import 'package:bucil/screens/content_absence_start.dart';
import 'package:bucil/screens/content_order_start.dart';
import 'package:package_info/package_info.dart';
import 'package:bucil/models/api.dart';
import 'package:bucil/models/auth.dart';
import 'package:bucil/models/cart.dart';
import 'package:bucil/models/category.dart';
import 'package:bucil/models/paymentmethod.dart';
import 'package:bucil/models/product.dart';
import 'package:bucil/models/salestype.dart';
import 'package:bucil/models/shift.dart';
import 'package:bucil/models/syncronize.dart';
import 'package:bucil/screens/content_history.dart';
import 'package:bucil/screens/content_history_recap.dart';
import 'package:bucil/screens/content_recap.dart';
import 'package:bucil/util/const.dart';
import 'package:bucil/util/dialog.dart';
import 'package:bucil/util/global.dart';
import 'package:bucil/widgets/widget_selling_products.dart';
import 'package:flutter/material.dart';
import '../printer_settings.dart';
import '../util/global.dart';
import 'package:bucil/screens/content_order_history.dart';

//PAGE CART
class ContentHome extends StatefulWidget {
  @override
  _ContentHomeState createState() => _ContentHomeState();
}

class _ContentHomeState extends State<ContentHome> {
  String version = "";
  bool logout = false;
  bool shiftOpen = false;
  List<Category> category;
  List<Product> product;
  List<Tab> categoryTabs;
  List<Widget> contents;
  Category categorySelected;
  bool isFetchingCategory = false;
  TabController tabController;
  int tabIndex;
  int pending = 0;
  int pendingShift = 0;

  Future<void> syncronizePending() async {
    if (Global.getSharedList(key: Prefs.PREFS_PENDING_SALES).length > 0) {
      final response = API.fromJson(
          await Syncronize.syncSales(context: context, showLoading: false));

      if (response.success) {
        Global.setSharedList(key: Prefs.PREFS_PENDING_SALES, value: []);
        pending = 0;
      }
    } else
      pending = 0;
  }

  Future<void> syncronizeShift() async {
    if (Global.getShared(key: Prefs.PREFS_PENDING_SHIFT, defaults: "") != "") {
      final response = API.fromJson(
          await Syncronize.syncShift(context: context, showLoading: false));

      if (response.success) pendingShift = 0;
    } else
      pendingShift = 0;
  }

  Future<void> checkShift() async {
    final response = API.fromJson(
        await Shift.selectExisting(context: context, showLoading: false));

    if (response.success) {
      shiftOpen = true;
      Global.setShared(key: Prefs.PREFS_USER_SHIFT, value: "1");
      Shift shift = new Shift.fromJson(response.data[0]);
      Global.setShared(key: Prefs.PREFS_USER_SHIFT_REMARK, value: shift.remark);
    } else {
      if (response.code == 400) {
        if (Global.getShared(key: Prefs.PREFS_USER_SHIFT, defaults: "0") == "1")
          shiftOpen = true;
        else
          shiftOpen = false;
      } else {
        String shift =
            Global.getShared(key: Prefs.PREFS_PENDING_SHIFT, defaults: "");
        if (shift != "") {
          shiftOpen = true;
          Global.setShared(key: Prefs.PREFS_USER_SHIFT, value: "1");
        } else {
          shiftOpen = false;
          Global.setShared(key: Prefs.PREFS_USER_SHIFT, value: "0");
        }
      }
    }
  }

  Future<void> fetchCategory() async {
    category = [];

    Category categoryDefault = Category.fromJson({
      "category_id": "0",
      "category_name": "Semua",
    });
    category.add(categoryDefault);
    categorySelected = categoryDefault;

    categoryDefault = Category.fromJson({
      "category_id": "-1",
      "category_name": "Fav",
    });
    category.add(categoryDefault);

    final response = API
        .fromJson(await Category.select(context: context, showLoading: false));

    if (response.success) {
      List<String> offline = [];
      response.data.forEach((data) {
        category.add(Category.fromJson(data));
        offline.add(jsonEncode(data));
      });
      Global.setSharedList(key: Prefs.PREFS_OFFLINE_CATEGORY, value: offline);
    } else {
      if (response.code == 401) {
        Auth.logout(context);
        logout = true;
      } else {
        List<String> offline = [];
        offline = Global.getSharedList(key: Prefs.PREFS_OFFLINE_CATEGORY);
        for (int i = 0; i < offline.length; i++) {
          category.add(Category.fromJson(jsonDecode(offline[i])));
        }
      }
    }
  }

  Future<void> fetchProduct() async {
    product = [];

    final response = API
        .fromJson(await Product.select(context: context, showLoading: false));
    if (response.success) {
      List<String> existing = [];
      existing = Global.getSharedList(key: Prefs.PREFS_OFFLINE_PRODUCT);

      List<String> offline = [];
      response.data.forEach((data) {
        product.add(Product.fromJson(data));
        offline.add(jsonEncode(data));
      });
      Global.setSharedList(key: Prefs.PREFS_OFFLINE_PRODUCT, value: offline);
    } else {
      List<String> offline = [];
      offline = Global.getSharedList(key: Prefs.PREFS_OFFLINE_PRODUCT);
      for (int i = 0; i < offline.length; i++) {
        product.add(Product.fromJson(jsonDecode(offline[i])));
      }
    }
  }

  Future<void> fetchPaymentmethod() async {
    final response = API.fromJson(
        await Paymentmethod.select(context: context, showLoading: false));
    if (response.success) {
      List<String> offline = [];
      response.data.forEach((data) {
        offline.add(jsonEncode(data));
      });
      Global.setSharedList(
          key: Prefs.PREFS_OFFLINE_PAYMENTMETHOD, value: offline);
    }
  }

  Future<void> fetchSalestype() async {
    final response = API
        .fromJson(await Salestype.select(context: context, showLoading: false));
    if (response.success) {
      List<String> offline = [];
      response.data.forEach((data) {
        offline.add(jsonEncode(data));
      });
      Global.setSharedList(key: Prefs.PREFS_OFFLINE_SALESTYPE, value: offline);
    }
  }

  Future<void> fetchCustomer() async {
    final response = API
        .fromJson(await Customer.select(context: context, showLoading: false));
    if (response.success) {
      List<String> offline = [];
      response.data.forEach((data) {
        offline.add(jsonEncode(data));
      });
      Global.setSharedList(key: Prefs.PREFS_OFFLINE_CUSTOMER, value: offline);
    }
  }

  @override
  void initState() {
    super.initState();
    PackageInfo.fromPlatform().then((PackageInfo packageInfo) {
      version = packageInfo.version;
    });

    Cart.clearCart();
    product = [];
    category = [];
    contents = [];
    categoryTabs = [];

    pending = Global.getSharedList(key: Prefs.PREFS_PENDING_SALES).length;
    String _shift =
        Global.getShared(key: Prefs.PREFS_PENDING_SHIFT, defaults: "");
    if (_shift != "") pendingShift = 1;

    Future.delayed(Duration.zero, () async {
      fetchData();
    });
  }

  Future<void> fetchData() async {
    logout = false;
    setState(() {
      isFetchingCategory = true;
    });

    if (pendingShift > 0) {
      await syncronizeShift();
    }

    if (pending > 0) {
      await syncronizePending();
    }

    await checkShift();
    //  await fetchCategory();
    if (!logout) await fetchProduct();
    if (!logout) await fetchSalestype();
    if (!logout) await fetchPaymentmethod();
    if (!logout) await fetchCustomer();

    setState(() {
      contents = [];
      categoryTabs = [];
      category.forEach((data) {
        categoryTabs.add(Tab(child: Text(data.name)));
        contents.add(ContentProduct(
          product: product,
          category: data,
        ));
      });
      isFetchingCategory = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: DefaultTabController(
        initialIndex: 0,
        length: category.length,
        child: Scaffold(
            drawer: Drawer(
              child: Column(
                children: <Widget>[
                  SizedBox(height: 20),
                  Text(
                    "v$version${Global.getServerCode()}",
                    style: TextStyle(fontSize: 8),
                  ),
                  SizedBox(height: 10),
                  Text(
                    Global.getShared(key: Prefs.PREFS_USER_NAME),
                    style: TextStyle(
                        fontStyle: FontStyle.italic,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Text(
                    Global.getShared(key: Prefs.PREFS_USER_STORE_NAME),
                    style: TextStyle(fontStyle: FontStyle.italic, fontSize: 12),
                  ),
                  SizedBox(height: 30),
                  if (!shiftOpen) ...[
                    InkWell(
                      onTap: () {
                        cash(0);
                      },
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 10),
                          child: Text("Buka Shift"),
                        ),
                      ),
                    ),
                    Divider(),
                  ] else ...[
                    InkWell(
                      onTap: () {
                        cash(2);
                      },
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 10),
                          child: Text("Rekapan Shift"),
                        ),
                      ),
                    ),
                    Divider(),
                  ],
                  InkWell(
                    onTap: () {
                      Global.materialNavigate(context, ContentHistory());
                    },
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        padding:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        child: Text("Riwayat"),
                      ),
                    ),
                  ),
                  Divider(),
                  if (Global.getShared(key: Prefs.PREFS_USER_TYPE) == "2") ...[
                    InkWell(
                      onTap: () {
                        Global.materialNavigate(context, ContentHistoryRecap());
                      },
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 10),
                          child: Text("Riwayat Shift"),
                        ),
                      ),
                    ),
                    Divider(),
                    InkWell(
                      onTap: () {
                        Global.materialNavigate(context, ContentOrderStart());
                      },
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 10),
                          child: Text("Pembelian"),
                        ),
                      ),
                    ),
                    Divider(),
                  ],
                  InkWell(
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        padding:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        child: Text("Refresh"),
                      ),
                    ),
                    onTap: () => fetchData(),
                  ),
                  Divider(),
                  InkWell(
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        padding:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        child: Text("Pengaturan Printer"),
                      ),
                    ),
                    onTap: () =>
                        Global.materialNavigate(context, PrinterSettings()),
                  ),
                  Divider(),
                  InkWell(
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        padding:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        child: Text("Absen"),
                      ),
                    ),
                    onTap: () =>
                        Global.materialNavigate(context, ContentAbsenceStart()),
                    // Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) {
                    //     return ContentAbsenceStart();
                    // }))
                  ),
                  Divider(),
                  Expanded(
                      child: Align(
                    alignment: Alignment.bottomCenter,
                    child: InkWell(
                      child: Container(
                        width: double.infinity,
                        color: Constants.darkAccent,
                        padding:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                        child: Text(
                          "Keluar",
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                      onTap: () {
                        Dialogs.showYesNo(
                            context: context,
                            text: "Apakah anda yakin untuk keluar?",
                            action: (result) {
                              if (result) {
                                Auth.logout(context);
                              }
                            });
                      },
                    ),
                  ))
                ],
              ),
            ),
            appBar: AppBar(
              backgroundColor: Constants.lightNavbarBG,
            ),
            // appBar: AppBar(
            //   actions: <Widget>[
            //     Stack(
            //       children: <Widget>[
            //         IconButton(
            //           icon: Icon(Icons.sync),
            //           onPressed: () {
            //             fetchData();
            //           },
            //         ),
            //         if (pending > 0) ...[
            //           Padding(
            //               padding: const EdgeInsets.all(10),
            //               child: Align(
            //                   alignment: Alignment.bottomRight,
            //                   child: Text(
            //                     (pending).toString(),
            //                     style: TextStyle(color: Colors.red),
            //                   )))
            //         ]
            //       ],
            //     ),
            //     // IconButton(
            //     //   icon: Icon(Icons.print),
            //     //   onPressed: () {
            //     //     Global.materialNavigate(context, PrinterSettings());
            //     //   },
            //     // ),
            //   ],
            //   backgroundColor: Constants.lightAccent,

            //   // title: Center(
            //   //     child: Text(
            //   //   "Transaksi",
            //   //   style: TextStyle(color: Constants.lightAccent),
            //   // )),

            //   bottom: TabBar(
            //     isScrollable: true,
            //     tabs: categoryTabs,
            //     onTap: (index) {
            //       setState(() {
            //         tabIndex = index;
            //         categorySelected = category[index];
            //         print('selected category: ${categorySelected.name}');
            //       });
            //     },
            //   ),
            // ),

            body: Column(
              children: <Widget>[
                if (isFetchingCategory) ...[
                  SizedBox(
                      width: 15,
                      height: 15,
                      child: CircularProgressIndicator(strokeWidth: 2)),
                ],
                //// Expanded(
                //   child: TabBarView(
                //     children: contents
                //  ),
                //   ),

                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(
                        'assets/image_onboarding.png',
                        width: 355,
                      ),
                      SizedBox(
                        height: 80,
                      ),
                      Text(
                        'Order',
                        style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w500,
                            color: Colors.black),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        'Reseller silakan order ',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w300,
                            color: Colors.black),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(
                        height: 70,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          GestureDetector(
                            onTap: () {
                              Global.materialNavigateReplace(
                                  context, ContentOrderHistory());
                              Global.materialNavigate(
                                  context, ContentOrderHistory());
                            },
                            child: Container(
                              padding: EdgeInsets.symmetric(
                                horizontal: 48,
                                vertical: 14,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.yellow,
                                borderRadius: BorderRadius.horizontal(
                                  left: Radius.circular(20),
                                ),
                              ),
                              child: Text(
                                'Start order >',
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.black),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            )),
      ),
    );
  }

  Future<void> cash(int _type) async {
    if (_type == 2) {
      if (pending > 0) {
        syncronizePending();
        Dialogs.showSimpleText(
            context: context, text: "Sinkron terlebih dahulu");
      } else if (pendingShift > 0) {
        syncronizeShift();
        Dialogs.showSimpleText(
            context: context, text: "Sinkron terlebih dahulu");
      } else {
        Global.materialNavigate(context, ContentRecap()).then((_) {
          fetchData();
        });
      }
    } else {
      Dialogs.showCash(
          context: context,
          type: _type,
          action: (result, value, note) async {
            if (result) {
              String date =
                  Global.getCurrentDate(format: Global.DATETIME_DATABASE);

              final response = API.fromJson(await Shift.input(
                  context: context,
                  type: _type,
                  date: date,
                  value: value,
                  note: note,
                  showLoading: true));

              if (!response.success) if (response.code == 401)
                Auth.logout(context);
              else {
                Dialogs.showSimpleText(
                    context: context,
                    text: "Kas masuk sebesar Rp. " +
                        Global.delimeter(number: value.toString()) +
                        " berhasil dimasukkan.");
                shiftOpen = true;
                Global.setShared(key: Prefs.PREFS_USER_SHIFT, value: "1");
                Global.setShared(
                    key: Prefs.PREFS_USER_SHIFT_REMARK, value: note);
                Syncronize.addPendingShift(
                    type: _type, date: date, value: value, note: note);
                setState(() {});
              }
              else {
                if (_type == 0) {
                  Dialogs.showSimpleText(
                      context: context,
                      text: "Kas masuk sebesar Rp. " +
                          Global.delimeter(number: value.toString()) +
                          " berhasil dimasukkan.");
                  shiftOpen = true;
                  Global.setShared(key: Prefs.PREFS_USER_SHIFT, value: "1");
                } else if (_type == 1) {
                  Dialogs.showSimpleText(
                      context: context,
                      text: "Kas keluar sebesar Rp. " +
                          Global.delimeter(number: value.toString()) +
                          " berhasil dimasukkan.");
                } else if (_type == 2) {
                  Dialogs.showSimpleText(
                      context: context, text: "Rekap shift berhasil.");
                  shiftOpen = false;
                }

                setState(() {});
              }
            }
          });
    }
  }
}
