import 'dart:convert';

import 'package:bucil/dialogs/customer.dart';
import 'package:bucil/models/cart_detail.dart';
import 'package:bucil/models/salestype.dart';
import 'package:bucil/screens/content_payment.dart';
import 'package:bucil/util/const.dart';
import 'package:bucil/util/dialog.dart';
import 'package:bucil/util/global.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:bucil/models/cart.dart';

//PAGE CART REVIEW
class ContentReview extends StatefulWidget {
  @override
  _ContentReviewState createState() => _ContentReviewState();
}

class _ContentReviewState extends State<ContentReview> {
  bool logout = false;
  int grandtotal = 0;
  TextEditingController _customerController = TextEditingController();
  TextEditingController _customerAddressController = TextEditingController();
  TextEditingController _customerPhoneController = TextEditingController();
  TextEditingController _customerController2 = TextEditingController();
  List<CartDetail> cart = [];
  List<Salestype> salestype = [];
  Salestype salestype_selected;

  @override
  void initState() {
    super.initState();
    _customerController.text = "";
    _customerPhoneController.text = "";
    _customerAddressController.text = "";
    _customerController2.text = "";
    refresh();
  }

  @override
  void dispose() {
    super.dispose();
    _customerController.dispose();
    _customerPhoneController.dispose();
    _customerAddressController.dispose();
    _customerController2.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.sync, color: Constants.lightNavbarBG),
              onPressed: null,
            ),
          ],
          backgroundColor: Constants.lightNavbarBG,
          title: Center(
              child: Text(
            "Review",
            style: TextStyle(color: Constants.lightAccent),
          ))),
      body: _content(),
    ));
  }

  Widget _content() {
    return Column(
      children: <Widget>[
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                detail(),
                contentSalestype(),
                contentCustomer(),
              //  contentCustomer2()
              ],
            ),
          ),
        ),
        submit(),
      ],
    );
  }

  Widget submit() {
    return InkWell(
      onTap: () {
        FocusScope.of(context).requestFocus(new FocusNode());
        Global.materialNavigate(
            context,
            ContentPayment(
                salestype_selected: salestype_selected,
                customer: _customerController.text,
                customerPhone: _customerPhoneController.text,
                customerAddress: _customerAddressController.text,
                customer2: _customerController2.text));
                
      },
      child: Container(
        padding: EdgeInsets.all(15),
        color: Constants.darkAccent,
        width: double.infinity,
        height: 70,
        child: Row(
          children: <Widget>[
            Expanded(
              flex: 3,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    "Total:",
                    style: TextStyle(color: Colors.white, fontSize: 12),
                  ),
                  Text(
                    "Rp. " + Global.delimeter(number: grandtotal.toString()),
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  )
                ],
              ),
            ),
            Expanded(
              flex: 1,
              child: Align(
                alignment: Alignment.centerRight,
                child: Icon(
                  Icons.chevron_right,
                  color: Colors.white,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget detail() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Divider(
          height: 1,
          color: Colors.grey,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          child: Text(
            "DETAIL",
          ),
        ),
        Divider(height: 1, color: Colors.grey),
        ListView.builder(
            itemCount: cart.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (BuildContext context, int index) {
              return InkWell(
                onTap: () {
                  Dialogs.showQtyDetail(
                      context: context,
                      qty: cart[index].qty,
                      notes: cart[index].notes,
                      action: (result, qty, notes) {
                        if (result) {
                          double different = qty - cart[index].qty;
                          Cart.addToCart(
                              context: context,
                              cartDetail: CartDetail.fromJson({
                            "product": cart[index].product,
                            "name": cart[index].name,
                            "has_stock": cart[index].hasStock,
                            "qty_database": cart[index].qtyDatabase,
                            "qty": different,
                            "price": cart[index].price,
                            "notes": notes,
                            "product_print": cart[index].productPrints
                          }));
                          refresh();
                        }
                      });
                },
                child: Container(
                  padding: const EdgeInsets.all(10),
                  color: Colors.white,
                  child: Row(
                    children: <Widget>[
                      SizedBox(
                        height: 50,
                        width: 50,
                        child: Container(
                          color: Colors.orange,
                          child: Center(
                            child: Text(
                              Global.delimeter(
                                  number: cart[index].qty.toString()),
                              style:
                                  TextStyle(fontSize: 20, color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Expanded(
                        flex: 5,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(cart[index].name,
                                style: TextStyle(fontSize: 14)),
                            Text(
                                "Harga: Rp. " +
                                    Global.delimeter(
                                        number: cart[index].price.toString()),
                                style: TextStyle(
                                    fontSize: 12, fontStyle: FontStyle.italic)),
                            
                            if(cart[index].notes != null) ...[  
                              Text(
                                cart[index].notes,
                                style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic))
                            ]
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              );
            }),
      ],
    );
  }

  Widget contentCustomer() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Divider(
          height: 1,
          color: Colors.grey,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          child: Text(
            "PELANGGAN",
          ),
        ),
        Divider(height: 1, color: Colors.grey),
        Container(
          color: Colors.white,
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          child: Column(children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  flex: 1,
                  child: TextFormField(
                    onTap: () {
                      CustomerDialog.show(context: context, action: (name, code, phone, address){
                        _customerController.text = name;
                        if(address != "") _customerAddressController.text = address;
                        if(phone != "") _customerPhoneController.text = phone;
                      });
                    },
                    controller: _customerController,
                    readOnly: true,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      contentPadding: EdgeInsets.only(top:0, bottom:-5),
                      focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.lightBlue),
                      ),
                      hintText: "Nama"
                    ),
                    style: TextStyle(
                      fontSize: 12,
                      height: 2
                    ),
                  ),
                ),
              ],
            ),
            Row(
              children: <Widget>[
                Expanded(
                  flex: 1,
                  child: TextFormField(
                    controller: _customerAddressController,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      contentPadding: EdgeInsets.only(top:0, bottom:-5),
                      focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.lightBlue),
                      ),
                      hintText: "Alamat"
                    ),
                    style: TextStyle(
                      fontSize: 12,
                      height: 2
                    ),
                  ),
                ),
              ],
            ),
            Row(
              children: <Widget>[
                Expanded(
                  flex: 1,
                  child: TextFormField(
                    controller: _customerPhoneController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      contentPadding: EdgeInsets.only(top:0, bottom:-5),
                      focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.lightBlue),
                      ),
                      hintText: "Telepon"
                    ),
                    style: TextStyle(
                      fontSize: 12,
                      height: 2
                    ),
                  ),
                ),
              ],
            )
          ]),
        )
      ],
    );
  }

Widget contentCustomer2() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Divider(
          height: 1,
          color: Colors.grey,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          child: Text(
            "Request ",
          ),
        ),
        Divider(height: 1, color: Colors.grey),
        Container(
          color: Colors.white,
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          child: Column(children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  flex: 1,
                  child: TextFormField(
                    controller: _customerController2,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.lightBlue),
                      ),
                    ),
                  ),
                )
              ],
            )
          ]),
        )
      ],
    );
  }


  Widget contentSalestype() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        if (salestype.length > 0) ...[
          Divider(
            height: 1,
            color: Colors.grey,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            child: Text(
              "TIPE PENJUALAN",
            ),
          ),
          Divider(height: 1, color: Colors.grey),
          SizedBox(
            height: 80,
            child: Container(
              color: Colors.white,
              child: ListView.builder(
                padding: EdgeInsets.symmetric(horizontal: 10),
                itemCount: salestype.length,
                scrollDirection: Axis.horizontal,
                itemBuilder: (BuildContext context, int index) {
                  return Center(
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          salestype_selected = salestype[index];
                        });
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(5)),
                          border: Border.all(color: Constants.darkAccent),
                          color: (salestype_selected.id == salestype[index].id)
                              ? Constants.darkAccent
                              : null,
                        ),
                        padding: EdgeInsets.all(15),
                        margin: EdgeInsets.all(5),
                        child: Text(
                          salestype[index].name,
                          style: TextStyle(
                            color:
                                (salestype_selected.id == salestype[index].id)
                                    ? Colors.white
                                    : Constants.darkAccent,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          )
        ] else
          Container()
      ],
    );
  }

  Future<void> refresh() async {
    List<String> currentCartDetail = [];
    cart = [];
    currentCartDetail = Global.getSharedList(key: Prefs.PREFS_CART_DETAIL);
    grandtotal = 0;
    currentCartDetail.forEach((data) {
      CartDetail cartDetail = CartDetail.fromJson(jsonDecode(data));
      grandtotal += (cartDetail.price * cartDetail.qty).round();
      cart.add(cartDetail);
    });

    logout = false;
    await fetchSalestype();

    if (mounted) setState(() {});
  }

  Future<void> fetchSalestype() async {
    List<String> offline = [];
    salestype = [];
    offline = Global.getSharedList(key: Prefs.PREFS_OFFLINE_SALESTYPE);
    bool selected = false;
    for (int i = 0; i < offline.length; i++) {
      if (!selected) {
        salestype_selected = Salestype.fromJson(jsonDecode(offline[i]));
        selected = true;
      }
      salestype.add(Salestype.fromJson(jsonDecode(offline[i])));
    }
  }
}
