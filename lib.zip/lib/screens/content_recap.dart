import 'dart:convert';

import 'package:bucil/models/api.dart';
import 'package:bucil/models/auth.dart';
import 'package:bucil/models/paymentmethod.dart';
import 'package:bucil/models/shift.dart';
import 'package:bucil/models/syncronize.dart';
import 'package:bucil/screens/content_recap_review.dart';
import 'package:bucil/util/const.dart';
import 'package:bucil/util/currency_format.dart';
import 'package:bucil/util/dialog.dart';
import 'package:bucil/util/global.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

//PAGE RECAP
class ContentRecap extends StatefulWidget {
  @override
  _ContentRecapState createState() => _ContentRecapState();
}

class _ContentRecapState extends State<ContentRecap> {
  List<Paymentmethod> _paymentmethod = [];
  List<TextEditingController> _recap = [];

  @override
  void initState() {
    super.initState();
    List<String> offline = [];
    offline = Global.getSharedList(key: Prefs.PREFS_OFFLINE_PAYMENTMETHOD);
    for (int i = 0; i < offline.length; i++) {
      _paymentmethod.add(Paymentmethod.fromJson(jsonDecode(offline[i])));
      TextEditingController tec = new TextEditingController();
      tec.text = "0";
      _recap.add(tec);
    }
  }

  @override
  void dispose() {
    super.dispose();
    for (int i = 0; i < _recap.length; i++) {
      _recap[i].dispose();
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          appBar: AppBar(
              leading: Container(),
              actions: <Widget>[
                IconButton(
                  icon: Icon(Icons.sync, color: Constants.lightNavbarBG),
                  onPressed: null,
                ),
              ],
              backgroundColor: Constants.lightAccent,
              title: Center(
                  child: Text(
                "Rekap Shift",
                style: TextStyle(color: Constants.lightNavbarBG),
              ))),
          body: _content()),
    );
  }

  Widget _content() {
    return Column(
      children: <Widget>[
        Expanded(
            child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: <Widget>[list(), submit()],
            ),
          ),
        ))
      ],
    );
  }

  /*
  Icon paymentIcon(int index){
    switch (index) {
      case 0:
        return Icon(MdiIcons.cash, color: Colors.green, size: 40,);
        break;
      case 1:
        return Icon(MdiIcons.creditCard, color: Colors.blue, size: 40,);
        break;
      case 2:
        return Icon(BucilPayIcon.dana, color: Colors.blue, size: 40,);
        break;
      case 3:
        return Icon(MdiIcons.card, color: Colors.green, size: 40,);
        break;
      case 4:
        return Icon(BucilPayIcon.gopay, color: Colors.green, size: 40,);
        break;
      case 5:
        return Icon(BucilPayIcon.ovo, color: Colors.purple, size: 40,);
        break;  
      default:
    }
  }
  */

  Widget list() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        for (int i = 0; i < _paymentmethod.length; i++) ...[
          Row(
            children: <Widget>[
              Expanded(
                  flex: 1,
                  child: _paymentmethod[i].icon != null &&
                          _paymentmethod[i].icon != ""
                      ? Padding(
                          padding: const EdgeInsets.only(right: 10),
                          child: CachedNetworkImage(
                            width: 40,
                            height: 40,
                            imageUrl: _paymentmethod[i].icon,
                            placeholder: (context, url) =>
                                new CircularProgressIndicator(
                                    strokeWidth: 2, value: 5),
                            errorWidget: (context, url, error) =>
                                new Icon(Icons.error),
                          ),
                        )
                      : Container()),
              Expanded(
                  flex: 5,
                  child: TextFormField(
                    controller: _recap[i],
                    decoration: InputDecoration(
                        labelText: _paymentmethod[i].name,
                        hintText: _paymentmethod[i].name),
                    keyboardType: TextInputType.number,
                    style: TextStyle(fontWeight: FontWeight.w300),
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                      CurrencyFormat()
                    ],
                  )),
            ],
          )
        ],
        SizedBox(height: 20)
      ],
    );
  }

  Widget submit() {
    return InkWell(
      onTap: () {
        int total = 0;
        List recapUser = [];
        for (int i = 0; i < _recap.length; i++) {
          total += int.parse(Global.unformatNumber(number: _recap[i].text));
          recapUser.add({
            "paymentmethod_id": _paymentmethod[i].id,
            "total_users": Global.unformatNumber(number: _recap[i].text)
          });
        }
        Dialogs.showYesNo(
            context: context,
            text: "Apakah anda yakin untuk melakukan rekap?",
            action: (result) async {
              if (result) {
                await Syncronize.syncShift(
                    context: context, showLoading: false);
                await Syncronize.syncSales(
                    context: context, showLoading: false);

                String date =
                    Global.getCurrentDate(format: Global.DATETIME_DATABASE);
                final response = API.fromJson(await Shift.recap(
                    context: context,
                    date: date,
                    total: total,
                    recap: recapUser));
                if (response.success) {
                  print(response.data);
                  Navigator.pop(context);
                  Global.materialNavigate(
                      context, ContentRecapReview(data: response.data));
                  //Dialogs.showSimpleText(context: context, text: "Rekap shift berhasil");
                } else {
                  if (response.code == 401)
                    Auth.logout(context);
                  else
                    Dialogs.showSimpleText(
                        context: context, text: response.message);
                }
              }
            });
      },
      child: Container(
          width: double.infinity,
          height: 50,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Constants.darkAccent),
              color: Constants.darkAccent),
          child: Center(
              child: Text(
            "Rekap",
            style: TextStyle(color: Colors.white),
          ))),
    );
  }
}
