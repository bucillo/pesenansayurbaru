import 'dart:convert';

import 'package:bucil/models/api.dart';
import 'package:bucil/models/order.dart';
import 'package:bucil/models/product.dart';
//import 'package:bucil/screens/content_order_history.dart';
import 'package:bucil/util/currency_format.dart';
import 'package:bucil/util/dialog.dart';
import 'package:bucil/util/global.dart';
import 'package:flutter/material.dart';
import 'package:bucil/util/const.dart';
import 'package:flutter/services.dart';

import 'content_order_history.dart';

class ContentOrder extends StatefulWidget {
  final Order order;
  final DateTime datetime;
  const ContentOrder({Key key, this.order, this.datetime}) : super(key: key);

  @override
  _ContentOrderState createState() => _ContentOrderState();
}

class _ContentOrderState extends State<ContentOrder> {
  var _isVisible;
  bool _loading = false;
  List<Product> _productFull = [];
  List<Product> _product = [];
  List<OrderDetail> _orderDetail = [];
  DateTime date = DateTime.now();
  List<String> offline = Global.getSharedList(key: Prefs.PREFS_OFFLINE_PRODUCT);
  TextEditingController _searchController = new TextEditingController();
  TextEditingController _qtyController = new TextEditingController();
  TextEditingController _priceController = new TextEditingController();
  TextEditingController _totalController = new TextEditingController();
  TextEditingController _customerController = new TextEditingController();
  TextEditingController _alamatController = new TextEditingController();
  TextEditingController _telpController = new TextEditingController();
  TextEditingController _descController = new TextEditingController();
  int _unitSelected = 0;

  @override
  void initState() {
    if (_orderDetail.isEmpty) {
      _isVisible = true;
    } else
      _isVisible = false;

    for (int i = 0; i < offline.length; i++) {
      Product product = Product.fromJson(jsonDecode(offline[i]));
      if (product.hasStock == "1") {
        _product.add(product);
        _productFull.add(product);
      }
    }
    if (widget.order != null) {
      widget.order.detail.forEach((data) {
        _orderDetail.add(OrderDetail.fromJson(data));
      });
      date = new DateTime(
          int.parse(Global.formatDate(
              date: widget.order.date, outputPattern: Global.DATETIME_YEAR)),
          int.parse(Global.formatDate(
              date: widget.order.date, outputPattern: Global.DATETIME_MONTH)),
          int.parse(Global.formatDate(
              date: widget.order.date, outputPattern: Global.DATETIME_DAY)));
    } else if (widget.datetime != null) date = widget.datetime;
    _searchController.addListener(search);
    super.initState();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _qtyController.dispose();
    _priceController.dispose();
    _totalController.dispose();
    _customerController.dispose();
    _alamatController.dispose();
    _telpController.dispose();
    _descController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Constants.lightNavbarBG,
        title: Text(
          "Order",
          style: TextStyle(color: Constants.lightAccent),
        ),
      ),

      // floatingActionButton:
      //   Container(
      //     child: FloatingActionButton(
      //       backgroundColor: Constants.lightAccent,
      //       tooltip: "Add",
      //       child: Icon(Icons.add, color: Constants.lightPrimary),
      //       onPressed: () {
      //         _dialogListItem();
      //       },
      //     ),
      //   ),

      floatingActionButton: new Visibility(
        visible: _isVisible,
        child: new FloatingActionButton(
          backgroundColor: Constants.lightAccent,
          tooltip: 'Add',
          child: new Icon(Icons.add),
          onPressed: () {
            _dialogListItem();
          },
        ),
      ),

      body: SafeArea(
          child: Container(
              child: SingleChildScrollView(
        physics: ScrollPhysics(),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      Global.selectDate(context, initialDate: date)
                          .then((dateNew) {
                        if (dateNew != null) {
                          date = dateNew;
                          setState(() {});
                        }
                      });
                    },
                    child: Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 48,
                        vertical: 14,
                      ),
                      margin: EdgeInsets.symmetric(horizontal: 10),
                      decoration: BoxDecoration(
                        color: Constants.darkAccent,
                        borderRadius: BorderRadius.horizontal(
                          left: Radius.circular(10),
                          right: Radius.circular(10),
                        ),
                      ),
                      child: Center(
                        child: Text(
                          Global.formatDate(
                              date: date.toString(),
                              inputPattern: Global.DATETIME_DATABASE,
                              outputPattern: Global.DATETIME_SHOW_DATE),
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                              color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(right: 10),
                  decoration: BoxDecoration(
                    color: Constants.darkAccent,
                    borderRadius: BorderRadius.horizontal(
                      left: Radius.circular(10),
                      right: Radius.circular(10),
                    ),
                  ),
                  child: IconButton(
                      icon: Icon(Icons.save, color: Colors.white),
                      onPressed: () {
                        save();
                      }),
                ),
              ],
            ),
            SizedBox(height: 20),
            ListView.builder(
              physics: NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              itemCount: _orderDetail.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  child: Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: ListTile(
                      title: Text(_orderDetail[index].productName),
                      subtitle: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("jumlah: " +
                                    Global.delimeter(
                                        number: _orderDetail[index].qty) +
                                    " " +
                                    _orderDetail[index].unit),
                                Text("harga: " +
                                    Global.delimeter(
                                        number: _orderDetail[index].price)),
                              ],
                            ),
                          ),
                          Container(
                              child: Text(
                            "Rp. " +
                                Global.delimeter(
                                    number: (double.parse(
                                                _orderDetail[index].price) *
                                            double.parse(
                                                _orderDetail[index].qty))
                                        .toString()),
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16),
                          )),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ))),
    );
  }

  void _dialogListItem() {
    showDialog(
        context: context,
        builder: (context) => StatefulBuilder(builder: (context, setState) {
              return AlertDialog(
                elevation: 24,
                title: Text("Item",
                    style: TextStyle(
                        fontFamily: 'OpenSans',
                        fontWeight: FontWeight.w700,
                        fontSize: 16)),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(5))),
                content: Container(
                  width: double.maxFinite,
                  height: 300,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextFormField(
                        onChanged: (value) {
                          setState(() {
                            _loading = true;
                            search();
                          });
                        },
                        controller: _searchController,
                        decoration: InputDecoration(
                            labelText: "Cari item",
                            hintText: "Search",
                            prefixIcon: Icon(Icons.search)),
                      ),
                      Expanded(
                        child: !_loading
                            ? ListView.separated(
                                separatorBuilder: (context, index) => Divider(
                                  color: Colors.black,
                                ),
                                shrinkWrap: true,
                                itemCount: _product.length,
                                itemBuilder: (context, index) {
                                  return InkWell(
                                    onTap: () {
                                      Dialogs.hideDialog(context: context);
                                      _dialogFormItem(
                                          productSelected: _product[index]);
                                    },
                                    child: ListTile(
                                      title: Text(_product[index].name),
                                    ),
                                  );
                                },
                              )
                            : Text("No records found"),
                      )
                    ],
                  ),
                ),
              );
            }));
  }

  void _dialogFormItem({@required Product productSelected}) {
    List<String> _unit = [];
    List<String> _unitConversion = [];
    _unitSelected = 0;
    _unit.add(productSelected.unit);
    _unitConversion.add("1");
    if (productSelected.unit2 != "") {
      _unit.add(productSelected.unit2);
      _unitConversion.add(productSelected.unitConversion2);
    }
    if (productSelected.unit3 != "") {
      _unit.add(productSelected.unit3);
      _unitConversion.add(productSelected.unitConversion3);
    }
    if (productSelected.unit4 != "") {
      _unit.add(productSelected.unit4);
      _unitConversion.add(productSelected.unitConversion4);
    }
    if (productSelected.unit5 != "") {
      _unit.add(productSelected.unit5);
      _unitConversion.add(productSelected.unitConversion5);
    }

    _qtyController.text = "0";
    _priceController.text = "0";
    _totalController.text = "0";
    _customerController.text = "a";
    _alamatController.text = "b";
    _telpController.text = "c";
    _descController.text = "d";

    setState(() {});

    showDialog(
        context: context,
        builder: (context) => StatefulBuilder(
              builder: (context, setStateChild) => AlertDialog(
                elevation: 24,
                title: Text(productSelected.name,
                    style: TextStyle(
                        fontFamily: 'OpenSans',
                        fontWeight: FontWeight.w700,
                        fontSize: 16)),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(5))),
                actions: <Widget>[
                  TextButton(
                    child: Text("Batal"),
                    onPressed: () {
                      Dialogs.hideDialog(context: context);
                    },
                  ),
                  TextButton(
                    child: Text("Tambah"),
                    onPressed: () {
                      // if (_qtyController.text == "" ||
                      //     _qtyController.text == "0")
                      //   Dialogs.showSimpleText(
                      //       context: context,
                      //       text: "Jumlah tidak boleh kosong");
                      // else if (_priceController.text == "")
                      //   Dialogs.showSimpleText(
                      //       context: context, text: "Harga tidak boleh kosong");
                      // else {
                      _orderDetail.add(new OrderDetail(
                          productId: productSelected.id,
                          productName: productSelected.name,
                          unit: _unit[_unitSelected],
                          unit1: productSelected.unit,
                          unit2: productSelected.unit2,
                          unit3: productSelected.unit3,
                          unit4: productSelected.unit4,
                          unit5: productSelected.unit5,
                          unitConversion: _unitConversion[_unitSelected],
                          unitConversion1: "1",
                          unitConversion2: productSelected.unitConversion2,
                          unitConversion3: productSelected.unitConversion3,
                          unitConversion4: productSelected.unitConversion4,
                          unitConversion5: productSelected.unitConversion5,
                          customer: _customerController.text,
                          alamat: _alamatController.text,
                          telp: _telpController.text,
                          desc: _descController.text,
                          price: Global.unformatNumber(
                              number: _priceController.text),
                          qty: Global.unformatNumber(
                              number: _qtyController.text)));
                      setState(() {});

                      if (_orderDetail.isEmpty) {
                        _isVisible = true;
                      } else
                        _isVisible = false;

                      Dialogs.hideDialog(context: context);
                      // }
                    },
                  )
                ],
                content: Container(
                  width: double.maxFinite,
                  height: 500,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Row(
                      //   mainAxisSize: MainAxisSize.max,
                      //   crossAxisAlignment: CrossAxisAlignment.center,
                      //   mainAxisAlignment: MainAxisAlignment.start,
                      //   children: [
                      //     Text("Jumlah:   "),
                      //     Flexible(
                      //       child: TextFormField(
                      //         controller: _qtyController,
                      //         keyboardType: TextInputType.numberWithOptions(
                      //             decimal: true, signed: false),
                      //         onChanged: (value) {
                      //           if (value == "") {
                      //             _totalController.text = "0";
                      //           } else {
                      //             String _unformat =
                      //                 Global.unformatNumber(number: value);
                      //             String _priceUnformat = Global.unformatNumber(
                      //                 number: _priceController.text);
                      //             if (_priceUnformat == "")
                      //               _priceUnformat = "0";
                      //             double _newTotal =
                      //                 double.parse(_priceUnformat) *
                      //                     double.parse(_unformat);
                      //             _totalController.text = Global.delimeter(
                      //                 number: _newTotal.toString());
                      //           }
                      //         },
                      //         style: TextStyle(
                      //           fontSize: 18,
                      //           fontWeight: FontWeight.bold,
                      //         ),
                      //         inputFormatters: [
                      //           // FilteringTextInputFormatter.digitsOnly,
                      //           CurrencyFormat()
                      //         ],
                      //       ),
                      //     ),
                      //   ],
                      // ),
                      // DropdownButton(
                      //   value: _unit[_unitSelected],
                      //   isExpanded: true,
                      //   items: _unit
                      //       .asMap()
                      //       .map((i, val) => MapEntry(
                      //           i,
                      //           new DropdownMenuItem<String>(
                      //             value: val,
                      //             child: new Text(val),
                      //           )))
                      //       .values
                      //       .toList(),
                      //   onChanged: (newValue) {
                      //     print(newValue);
                      //     print(_unit.indexOf(newValue));
                      //     setStateChild(() {
                      //       _unitSelected = _unit.indexOf(newValue);
                      //     });
                      //     setState(() {
                      //       _unitSelected = _unit.indexOf(newValue);
                      //     });
                      //   },
                      // ),

                      ////////////////////////////
                      // Row(
                      //   mainAxisSize: MainAxisSize.max,
                      //   crossAxisAlignment: CrossAxisAlignment.center,
                      //   mainAxisAlignment: MainAxisAlignment.start,
                      //   children: [
                      //     Text("Harga:   "),
                      //     Flexible(
                      //       child: TextFormField(
                      //         controller: _priceController,
                      //         keyboardType: TextInputType.number,
                      //         onChanged: (value) {
                      //           if (value == "")
                      //             _totalController.text = "";
                      //           else {
                      //             String _unformat =
                      //                 Global.unformatNumber(number: value);
                      //             String _qtyUnformat = Global.unformatNumber(
                      //                 number: _qtyController.text);
                      //             if (_qtyUnformat == "") _qtyUnformat = "0";
                      //             double _newTotal =
                      //                 double.parse(_qtyUnformat) *
                      //                     double.parse(_unformat);
                      //             _totalController.text = Global.delimeter(
                      //                 number: _newTotal.toString());
                      //           }
                      //         },
                      //         style: TextStyle(
                      //           fontSize: 18,
                      //           fontWeight: FontWeight.bold,
                      //         ),
                      //         inputFormatters: [
                      //           FilteringTextInputFormatter.digitsOnly,
                      //           CurrencyFormat()
                      //         ],
                      //       ),
                      //     ),
                      //   ],
                      // ),
                      // Row(
                      //   mainAxisSize: MainAxisSize.max,
                      //   crossAxisAlignment: CrossAxisAlignment.center,
                      //   mainAxisAlignment: MainAxisAlignment.start,
                      //   children: [
                      //     Text("Total:   "),
                      //     Flexible(
                      //       child: TextFormField(
                      //         controller: _totalController,
                      //         keyboardType: TextInputType.number,
                      //         onChanged: (value) {
                      //           if (value == "")
                      //             _priceController.text = "";
                      //           else {
                      //             String _unformat =
                      //                 Global.unformatNumber(number: value);
                      //             String _qtyUnformat = Global.unformatNumber(
                      //                 number: _qtyController.text);
                      //             if (_qtyUnformat == "") _qtyUnformat = "0";
                      //             double _newPrice = double.parse(_unformat) /
                      //                 double.parse(_qtyUnformat);
                      //             _priceController.text = Global.delimeter(
                      //                 number: _newPrice.toString());
                      //           }
                      //         },
                      //         style: TextStyle(
                      //           fontSize: 18,
                      //           fontWeight: FontWeight.bold,
                      //         ),
                      //         inputFormatters: [
                      //           FilteringTextInputFormatter.digitsOnly,
                      //           CurrencyFormat()
                      //         ],
                      //       ),
                      //     ),
                      //   ],
                      // ),
///////////////////////////////////////////////////////

                      Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text("Customer :   "),
                          Flexible(
                            child: TextFormField(
                              controller: _customerController,
                              keyboardType: TextInputType.multiline,
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text("Alamat :   "),
                          Flexible(
                            child: TextFormField(
                              controller: _alamatController,
                              keyboardType: TextInputType.multiline,
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text("Telp :   "),
                          Flexible(
                            child: TextFormField(
                              controller: _telpController,
                              keyboardType: TextInputType.multiline,
                              onChanged: (value) {},
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),

                      Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(" "),
                          // Flexible(
                          //   child: TextFormField(
                          //     maxLines: 5,
                          //     controller: _descController,
                          //     keyboardType: TextInputType.multiline,
                          //     onChanged: (value) {},
                          //     style: TextStyle(
                          //       fontSize: 18,
                          //       fontWeight: FontWeight.bold,
                          //     ),
                          //   ),
                          // ),
                        ],
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text("Keterangan :   "),
                          // Flexible(
                          //   child: TextFormField(
                          //     maxLines: 5,
                          //     controller: _descController,
                          //     keyboardType: TextInputType.multiline,
                          //     onChanged: (value) {},
                          //     style: TextStyle(
                          //       fontSize: 18,
                          //       fontWeight: FontWeight.bold,
                          //     ),
                          //   ),
                          // ),
                        ],
                      ),

                      Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          //Text("Keterangan :   "),
                          Flexible(
                            child: TextFormField(
                              maxLines: 5,
                              controller: _descController,
                              keyboardType: TextInputType.multiline,
                              onChanged: (value) {},
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ));
  }

  void search() {
    setState(() {
      _product = [];
      _productFull.forEach((data) {
        if (Global.contains(
            textData: data.name, textSearch: _searchController.text)) {
          _product.add(data);
        }
      });
      _loading = false;
      print(_product.length);
    });
  }

  Future<void> save() async {
    if (_orderDetail.isEmpty) {
      _isVisible = false;
      Dialogs.showSimpleText(
          context: context, text: "Tambah produk terlebih dahulu");
    } else {
      _isVisible = true;
      double total = 0;
      for (int i = 0; i < _orderDetail.length; i++) {
        total += double.parse(_orderDetail[i].price) *
            double.parse(_orderDetail[i].qty);
      }

      if (widget.order == null) {
        if (Global.formatDate(
                date: date.toString(),
                outputPattern: Global.DATETIME_DATABASE_DATE) ==
            Global.formatDate(
                date: DateTime.now().toString(),
                outputPattern: Global.DATETIME_DATABASE_DATE)) {
          date = DateTime.now();
        }

        final response = API.fromJson(await Order.insert(
            context: context,
            date: date.toString(),
            orderDetail: _orderDetail,
            total: total.toString()));
        if (response.success) {
          Global.materialNavigateReplace(context, ContentOrderHistory());
          Dialogs.hideDialog(context: context);
        } else
          Dialogs.showSimpleText(context: context, text: response.message);
      } else {
        final response = API.fromJson(await Order.update(
            context: context,
            code: widget.order.id,
            date: date.toString(),
            orderDetail: _orderDetail,
            total: total.toString()));
        if (response.success) {
          Dialogs.hideDialog(context: context);
        } else
          Dialogs.showSimpleText(context: context, text: response.message);
      }
    }
  }
}
